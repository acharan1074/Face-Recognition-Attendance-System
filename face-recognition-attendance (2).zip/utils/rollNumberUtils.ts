// Utility functions for roll number analysis and grouping

export interface RollNumberInfo {
  fullRollNumber: string
  yearBatch: string // First 4 digits (e.g., "22D0", "23D0")
  departmentSection: string // Last 4 digits (e.g., "6601", "7201")
  year: string // Extracted year (e.g., "2022", "2023")
  department: string // Department code (e.g., "66", "72", "05")
  section: string // Section code (e.g., "01")
}

export interface AttendanceGroup {
  groupKey: string
  groupName: string
  yearBatch: string
  departmentSection: string
  students: any[]
  attendanceRecords: any[]
  totalStudents: number
  presentToday: number
  attendanceRate: number
}

// Parse roll number to extract components
export const parseRollNumber = (rollNumber: string): RollNumberInfo | null => {
  // Expected format: XXDXXAXXX (e.g., 22D01A6601)
  const rollRegex = /^(\d{2}D\d{1})([A-Z])(\d{4})$/
  const match = rollNumber.match(rollRegex)

  if (!match) {
    return null
  }

  const yearBatch = match[1] // e.g., "22D0"
  const departmentLetter = match[2] // e.g., "A"
  const departmentSection = match[3] // e.g., "6601"

  // Extract year (20XX format)
  const yearPrefix = rollNumber.substring(0, 2)
  const year = `20${yearPrefix}`

  // Extract department code (first 2 digits of last 4)
  const department = departmentSection.substring(0, 2)

  // Extract section code (last 2 digits)
  const section = departmentSection.substring(2, 4)

  return {
    fullRollNumber: rollNumber,
    yearBatch: yearBatch + departmentLetter,
    departmentSection,
    year,
    department,
    section,
  }
}

// Get department name based on code
export const getDepartmentName = (departmentCode: string): string => {
  const departmentMap: { [key: string]: string } = {
    "66": "Computer Science & Engineering",
    "72": "Electronics & Communication Engineering",
    "05": "Civil Engineering",
    "04": "Mechanical Engineering",
    "03": "Electrical & Electronics Engineering",
    "01": "Information Technology",
    "67": "Computer Science & Information Technology",
    "31": "Electronics & Instrumentation Engineering",
    "21": "Chemical Engineering",
    "12": "Biotechnology",
  }

  return departmentMap[departmentCode] || `Department ${departmentCode}`
}

// Group students by roll number pattern
export const groupStudentsByRollNumber = (students: any[]): AttendanceGroup[] => {
  const groups: { [key: string]: AttendanceGroup } = {}

  students.forEach((student) => {
    const rollInfo = parseRollNumber(student.rollNumber)
    if (!rollInfo) return

    const groupKey = `${rollInfo.yearBatch}-${rollInfo.departmentSection}`

    if (!groups[groupKey]) {
      const departmentName = getDepartmentName(rollInfo.department)
      groups[groupKey] = {
        groupKey,
        groupName: `${rollInfo.year} - ${departmentName} - Section ${rollInfo.section}`,
        yearBatch: rollInfo.yearBatch,
        departmentSection: rollInfo.departmentSection,
        students: [],
        attendanceRecords: [],
        totalStudents: 0,
        presentToday: 0,
        attendanceRate: 0,
      }
    }

    groups[groupKey].students.push(student)
    groups[groupKey].totalStudents++
  })

  return Object.values(groups)
}

// Group attendance records by roll number pattern
export const groupAttendanceByRollNumber = (attendanceRecords: any[], students: any[]): AttendanceGroup[] => {
  const groups = groupStudentsByRollNumber(students)
  const today = new Date().toDateString()

  // Add attendance records to respective groups
  attendanceRecords.forEach((record) => {
    const student = students.find((s) => s.rollNumber === record.rollNumber)
    if (!student) return

    const rollInfo = parseRollNumber(student.rollNumber)
    if (!rollInfo) return

    const groupKey = `${rollInfo.yearBatch}-${rollInfo.departmentSection}`
    const group = groups.find((g) => g.groupKey === groupKey)

    if (group) {
      group.attendanceRecords.push(record)

      // Count today's attendance
      if (new Date(record.date).toDateString() === today) {
        group.presentToday++
      }
    }
  })

  // Calculate attendance rates
  groups.forEach((group) => {
    group.attendanceRate = group.totalStudents > 0 ? Math.round((group.presentToday / group.totalStudents) * 100) : 0
  })

  return groups.sort((a, b) => a.groupName.localeCompare(b.groupName))
}

// Filter data by date range for cleanup
export const filterDataByDateRange = (data: any[], cutoffDate: string, keepAfter = true): any[] => {
  const cutoff = new Date(cutoffDate)

  return data.filter((item) => {
    const itemDate = new Date(item.date || item.dateAdded || item.captureTime)
    return keepAfter ? itemDate >= cutoff : itemDate < cutoff
  })
}

// Get data statistics for cleanup decisions
export const getDataStatistics = () => {
  const students = JSON.parse(localStorage.getItem("students") || "[]")
  const attendance = JSON.parse(localStorage.getItem("attendance") || "[]")
  const captures = JSON.parse(localStorage.getItem("dailyCaptures") || "[]")

  const now = new Date()
  const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000)
  const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000)

  return {
    students: {
      total: students.length,
      groups: groupStudentsByRollNumber(students).length,
    },
    attendance: {
      total: attendance.length,
      lastWeek: attendance.filter((r: any) => new Date(r.date) >= sevenDaysAgo).length,
      lastMonth: attendance.filter((r: any) => new Date(r.date) >= thirtyDaysAgo).length,
      older: attendance.filter((r: any) => new Date(r.date) < thirtyDaysAgo).length,
    },
    captures: {
      total: captures.length,
      lastWeek: captures.filter((c: any) => new Date(c.captureTime) >= sevenDaysAgo).length,
      lastMonth: captures.filter((c: any) => new Date(c.captureTime) >= thirtyDaysAgo).length,
      older: captures.filter((c: any) => new Date(c.captureTime) < thirtyDaysAgo).length,
    },
  }
}

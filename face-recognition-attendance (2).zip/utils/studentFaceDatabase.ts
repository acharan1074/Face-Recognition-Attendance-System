// Enhanced student face database with detailed landmark analysis

import {
  type EnhancedFaceGeometry,
  detectDetailedFacialLandmarks,
  compareEnhancedFaceGeometries,
} from "./facialLandmarks"

export interface EnhancedStudentFaceProfile {
  studentId: string
  name: string
  rollNumber: string
  faceGeometries: EnhancedFaceGeometry[]
  averageDimensions: any
  landmarkStats: {
    totalLandmarks: number
    averageLandmarks: number
    qualityScore: number
  }
  createdAt: string
  lastUpdated: string
}

export class EnhancedStudentFaceDatabase {
  private static instance: EnhancedStudentFaceDatabase
  private profiles: Map<string, EnhancedStudentFaceProfile> = new Map()

  static getInstance(): EnhancedStudentFaceDatabase {
    if (!EnhancedStudentFaceDatabase.instance) {
      EnhancedStudentFaceDatabase.instance = new EnhancedStudentFaceDatabase()
    }
    return EnhancedStudentFaceDatabase.instance
  }

  async addStudentProfile(student: any, imageData: string): Promise<boolean> {
    try {
      const geometry = await detectDetailedFacialLandmarks(imageData)
      if (!geometry) {
        throw new Error("Could not detect detailed facial landmarks")
      }

      const existingProfile = this.profiles.get(student.id)

      if (existingProfile) {
        // Add new geometry to existing profile
        existingProfile.faceGeometries.push(geometry)
        existingProfile.lastUpdated = new Date().toISOString()
        this.updateProfileStats(existingProfile)
      } else {
        // Create new profile
        const profile: EnhancedStudentFaceProfile = {
          studentId: student.id,
          name: student.name,
          rollNumber: student.rollNumber,
          faceGeometries: [geometry],
          averageDimensions: geometry.dimensions,
          landmarkStats: {
            totalLandmarks: geometry.landmarkCount,
            averageLandmarks: geometry.landmarkCount,
            qualityScore: geometry.confidence,
          },
          createdAt: new Date().toISOString(),
          lastUpdated: new Date().toISOString(),
        }
        this.profiles.set(student.id, profile)
      }

      this.saveToStorage()
      return true
    } catch (error) {
      console.error("Error adding enhanced student profile:", error)
      return false
    }
  }

  async identifyStudent(imageData: string): Promise<{
    student: EnhancedStudentFaceProfile | null
    confidence: number
    matchDetails: any
    landmarkAnalysis: any
  }> {
    try {
      const queryGeometry = await detectDetailedFacialLandmarks(imageData)
      if (!queryGeometry) {
        return {
          student: null,
          confidence: 0,
          matchDetails: null,
          landmarkAnalysis: null,
        }
      }

      let bestMatch: EnhancedStudentFaceProfile | null = null
      let bestConfidence = 0
      let bestMatchDetails: any = null

      for (const profile of this.profiles.values()) {
        // Compare against all stored geometries for this student
        const similarities = profile.faceGeometries.map((geometry) =>
          compareEnhancedFaceGeometries(queryGeometry, geometry),
        )

        // Use weighted scoring based on landmark quality
        const weightedSimilarities = similarities.map((sim, index) => {
          const geometryQuality = profile.faceGeometries[index].confidence
          return sim * (0.7 + geometryQuality * 0.3)
        })

        const maxSimilarity = Math.max(...weightedSimilarities)
        const avgSimilarity = weightedSimilarities.reduce((sum, sim) => sum + sim, 0) / weightedSimilarities.length

        // Enhanced scoring with landmark count consideration
        const landmarkBonus = Math.min(queryGeometry.landmarkCount / 60, 1) * 0.1
        const combinedScore = maxSimilarity * 0.6 + avgSimilarity * 0.4 + landmarkBonus

        if (combinedScore > bestConfidence) {
          bestConfidence = combinedScore
          bestMatch = profile
          bestMatchDetails = {
            maxSimilarity,
            avgSimilarity,
            combinedScore,
            geometryCount: profile.faceGeometries.length,
            landmarkCount: queryGeometry.landmarkCount,
            qualityMetrics: queryGeometry.qualityMetrics,
          }
        }
      }

      const landmarkAnalysis = {
        detectedLandmarks: queryGeometry?.landmarkCount || 0,
        qualityScore: queryGeometry?.confidence || 0,
        symmetryScore: queryGeometry?.qualityMetrics.symmetry || 0,
        clarityScore: queryGeometry?.qualityMetrics.clarity || 0,
      }

      return {
        student: bestMatch,
        confidence: bestConfidence,
        matchDetails: bestMatchDetails,
        landmarkAnalysis,
      }
    } catch (error) {
      console.error("Error identifying student with enhanced landmarks:", error)
      return {
        student: null,
        confidence: 0,
        matchDetails: null,
        landmarkAnalysis: null,
      }
    }
  }

  private updateProfileStats(profile: EnhancedStudentFaceProfile) {
    const geometries = profile.faceGeometries

    // Update landmark statistics
    profile.landmarkStats = {
      totalLandmarks: geometries.reduce((sum, g) => sum + g.landmarkCount, 0),
      averageLandmarks: geometries.reduce((sum, g) => sum + g.landmarkCount, 0) / geometries.length,
      qualityScore: geometries.reduce((sum, g) => sum + g.confidence, 0) / geometries.length,
    }

    // Update average dimensions
    profile.averageDimensions = {
      eyeDistance: geometries.reduce((sum, g) => sum + g.dimensions.eyeDistance, 0) / geometries.length,
      noseWidth: geometries.reduce((sum, g) => sum + g.dimensions.noseWidth, 0) / geometries.length,
      mouthWidth: geometries.reduce((sum, g) => sum + g.dimensions.mouthWidth, 0) / geometries.length,
      faceWidth: geometries.reduce((sum, g) => sum + g.dimensions.faceWidth, 0) / geometries.length,
      faceHeight: geometries.reduce((sum, g) => sum + g.dimensions.faceHeight, 0) / geometries.length,
      eyeToNoseRatio: geometries.reduce((sum, g) => sum + g.dimensions.eyeToNoseRatio, 0) / geometries.length,
      faceAspectRatio: geometries.reduce((sum, g) => sum + g.dimensions.faceAspectRatio, 0) / geometries.length,
    }
  }

  private saveToStorage() {
    const data = Array.from(this.profiles.entries())
    localStorage.setItem("enhancedStudentFaceProfiles", JSON.stringify(data))
  }

  loadFromStorage() {
    try {
      const data = localStorage.getItem("enhancedStudentFaceProfiles")
      if (data) {
        const entries = JSON.parse(data)
        this.profiles = new Map(entries)
      }
    } catch (error) {
      console.error("Error loading enhanced face profiles:", error)
    }
  }

  getEnhancedProfileStats() {
    const profiles = Array.from(this.profiles.values())
    return {
      totalProfiles: profiles.length,
      totalGeometries: profiles.reduce((sum, p) => sum + p.faceGeometries.length, 0),
      avgGeometriesPerStudent:
        profiles.length > 0 ? profiles.reduce((sum, p) => sum + p.faceGeometries.length, 0) / profiles.length : 0,
      avgLandmarksPerProfile:
        profiles.length > 0
          ? profiles.reduce((sum, p) => sum + p.landmarkStats.averageLandmarks, 0) / profiles.length
          : 0,
      avgQualityScore:
        profiles.length > 0 ? profiles.reduce((sum, p) => sum + p.landmarkStats.qualityScore, 0) / profiles.length : 0,
    }
  }

  removeStudentProfile(studentId: string): boolean {
    const removed = this.profiles.delete(studentId)
    if (removed) {
      this.saveToStorage()
    }
    return removed
  }
}

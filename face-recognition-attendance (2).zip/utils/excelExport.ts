// Excel export utility using SheetJS
export const exportToExcel = (data: any[], filename: string, sheetName = "Sheet1") => {
  // Create workbook and worksheet
  const wb = {
    SheetNames: [sheetName],
    Sheets: {} as any,
  }

  // Convert data to worksheet format
  const ws = arrayToWorksheet(data)
  wb.Sheets[sheetName] = ws

  // Generate Excel file
  const excelBuffer = writeWorkbook(wb)

  // Create blob and download
  const blob = new Blob([excelBuffer], {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  })

  const url = window.URL.createObjectURL(blob)
  const a = document.createElement("a")
  a.href = url
  a.download = filename
  document.body.appendChild(a)
  a.click()
  document.body.removeChild(a)
  window.URL.revokeObjectURL(url)
}

// Simple array to worksheet conversion
const arrayToWorksheet = (data: any[]) => {
  if (data.length === 0) return {}

  const headers = Object.keys(data[0])
  const ws: any = {}

  // Add headers
  headers.forEach((header, colIndex) => {
    const cellAddress = getCellAddress(0, colIndex)
    ws[cellAddress] = { v: header, t: "s" }
  })

  // Add data rows
  data.forEach((row, rowIndex) => {
    headers.forEach((header, colIndex) => {
      const cellAddress = getCellAddress(rowIndex + 1, colIndex)
      const value = row[header]
      ws[cellAddress] = { v: value, t: typeof value === "number" ? "n" : "s" }
    })
  })

  // Set range
  const range = `A1:${getCellAddress(data.length, headers.length - 1)}`
  ws["!ref"] = range

  return ws
}

// Convert row/col to Excel cell address (A1, B2, etc.)
const getCellAddress = (row: number, col: number): string => {
  let colStr = ""
  let colNum = col

  while (colNum >= 0) {
    colStr = String.fromCharCode(65 + (colNum % 26)) + colStr
    colNum = Math.floor(colNum / 26) - 1
  }

  return colStr + (row + 1)
}

// Simple workbook writer
const writeWorkbook = (wb: any): ArrayBuffer => {
  // This is a simplified implementation
  // In a real application, you would use a library like SheetJS (xlsx)
  const csvContent = convertWorkbookToCSV(wb)
  const encoder = new TextEncoder()
  return encoder.encode(csvContent).buffer
}

const convertWorkbookToCSV = (wb: any): string => {
  const sheetName = wb.SheetNames[0]
  const ws = wb.Sheets[sheetName]

  if (!ws["!ref"]) return ""

  const range = parseRange(ws["!ref"])
  const rows: string[] = []

  for (let row = range.start.row; row <= range.end.row; row++) {
    const rowData: string[] = []
    for (let col = range.start.col; col <= range.end.col; col++) {
      const cellAddress = getCellAddress(row, col)
      const cell = ws[cellAddress]
      rowData.push(cell ? String(cell.v) : "")
    }
    rows.push(rowData.join(","))
  }

  return rows.join("\n")
}

const parseRange = (range: string) => {
  const [start, end] = range.split(":")
  return {
    start: parseCellAddress(start),
    end: parseCellAddress(end),
  }
}

const parseCellAddress = (address: string) => {
  const match = address.match(/([A-Z]+)(\d+)/)
  if (!match) return { row: 0, col: 0 }

  const colStr = match[1]
  const rowNum = Number.parseInt(match[2]) - 1

  let col = 0
  for (let i = 0; i < colStr.length; i++) {
    col = col * 26 + (colStr.charCodeAt(i) - 64)
  }
  col -= 1

  return { row: rowNum, col }
}

// Daily report generator
export const generateDailyReport = (attendance: any[], students: any[], date: string) => {
  const dailyAttendance = attendance.filter((record) => record.date === date)
  const presentStudents = new Set(dailyAttendance.map((record) => record.rollNumber))

  const reportData = students.map((student) => ({
    "Roll Number": student.rollNumber,
    "Student Name": student.name,
    Status: presentStudents.has(student.rollNumber) ? "Present" : "Absent",
    Time: dailyAttendance.find((record) => record.rollNumber === student.rollNumber)?.time || "-",
    Date: date,
  }))

  // Add summary
  const summary = {
    "Roll Number": "",
    "Student Name": "SUMMARY",
    Status: `${presentStudents.size}/${students.length} Present`,
    Time: `${Math.round((presentStudents.size / students.length) * 100)}% Attendance`,
    Date: date,
  }

  return [...reportData, {}, summary]
}

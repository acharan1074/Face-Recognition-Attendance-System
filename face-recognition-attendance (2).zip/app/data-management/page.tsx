"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  ArrowLeft,
  Trash2,
  Download,
  Users,
  Calendar,
  Database,
  AlertTriangle,
  CheckCircle,
  Filter,
} from "lucide-react"
import Link from "next/link"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  groupAttendanceByRollNumber,
  filterDataByDateRange,
  getDataStatistics,
  parseRollNumber, // Import parseRollNumber
  type AttendanceGroup,
} from "@/utils/rollNumberUtils"
import { exportToExcel as saveAsExcel } from "@/utils/excelExport"

export default function DataManagementPage() {
  const [students, setStudents] = useState<any[]>([])
  const [attendance, setAttendance] = useState<any[]>([])
  const [captures, setCaptures] = useState<any[]>([])
  const [attendanceGroups, setAttendanceGroups] = useState<AttendanceGroup[]>([])
  const [selectedGroup, setSelectedGroup] = useState<string>("all")
  const [cleanupDate, setCleanupDate] = useState("")
  const [cleanupType, setCleanupType] = useState<"attendance" | "captures" | "both">("both")
  const [alert, setAlert] = useState<{ type: "success" | "error" | "warning"; message: string } | null>(null)
  const [dataStats, setDataStats] = useState<any>(null)
  const [showConfirmDialog, setShowConfirmDialog] = useState(false)
  const [showGroupDeleteConfirmDialog, setShowGroupDeleteConfirmDialog] = useState(false) // New state for group delete confirmation
  const [groupToDelete, setGroupToDelete] = useState<AttendanceGroup | null>(null) // New state to store group to delete

  useEffect(() => {
    loadData()
    calculateStats()

    // Set default cleanup date (30 days ago)
    const thirtyDaysAgo = new Date()
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30)
    setCleanupDate(thirtyDaysAgo.toISOString().split("T")[0])
  }, [])

  useEffect(() => {
    if (alert) {
      const timer = setTimeout(() => setAlert(null), 4000)
      return () => clearTimeout(timer)
    }
  }, [alert])

  const loadData = () => {
    const savedStudents = JSON.parse(localStorage.getItem("students") || "[]")
    const savedAttendance = JSON.parse(localStorage.getItem("attendance") || "[]")
    const savedCaptures = JSON.parse(localStorage.getItem("dailyCaptures") || "[]")

    setStudents(savedStudents)
    setAttendance(savedAttendance)
    setCaptures(savedCaptures)

    // Group attendance by roll number patterns
    const groups = groupAttendanceByRollNumber(savedAttendance, savedStudents)
    setAttendanceGroups(groups)
  }

  const calculateStats = () => {
    const stats = getDataStatistics()
    setDataStats(stats)
  }

  const cleanupOldData = () => {
    if (!cleanupDate) {
      setAlert({ type: "error", message: "Please select a cleanup date" })
      return
    }

    let attendanceToKeep = attendance
    let capturesToKeep = captures

    if (cleanupType === "attendance" || cleanupType === "both") {
      attendanceToKeep = filterDataByDateRange(attendance, cleanupDate, true)
    }

    if (cleanupType === "captures" || cleanupType === "both") {
      capturesToKeep = filterDataByDateRange(captures, cleanupDate, true)
    }

    const attendanceRemoved = attendance.length - attendanceToKeep.length
    const capturesRemoved = captures.length - capturesToKeep.length

    // Update localStorage
    localStorage.setItem("attendance", JSON.stringify(attendanceToKeep))
    localStorage.setItem("dailyCaptures", JSON.stringify(capturesToKeep))

    // Update state
    setAttendance(attendanceToKeep)
    setCaptures(capturesToKeep)

    // Recalculate groups
    const groups = groupAttendanceByRollNumber(attendanceToKeep, students)
    setAttendanceGroups(groups)

    calculateStats()
    setShowConfirmDialog(false)

    setAlert({
      type: "success",
      message: `Cleanup completed! Removed ${attendanceRemoved} attendance records and ${capturesRemoved} capture images.`,
    })
  }

  const handleDeleteGroupData = (group: AttendanceGroup) => {
    setGroupToDelete(group)
    setShowGroupDeleteConfirmDialog(true)
  }

  const confirmDeleteGroupData = () => {
    if (!groupToDelete) return

    const groupKeyToDelete = groupToDelete.groupKey

    // Filter attendance records
    const updatedAttendance = attendance.filter((record) => {
      const rollInfo = parseRollNumber(record.rollNumber)
      return !rollInfo || `${rollInfo.yearBatch}-${rollInfo.departmentSection}` !== groupKeyToDelete
    })

    // Filter capture images
    const updatedCaptures = captures.filter((capture) => {
      const student = students.find((s) => s.rollNumber === capture.rollNumber)
      if (!student) return true // Keep if student not found (shouldn't happen if data is consistent)
      const rollInfo = parseRollNumber(student.rollNumber)
      return !rollInfo || `${rollInfo.yearBatch}-${rollInfo.departmentSection}` !== groupKeyToDelete
    })

    const attendanceRemoved = attendance.length - updatedAttendance.length
    const capturesRemoved = captures.length - updatedCaptures.length

    localStorage.setItem("attendance", JSON.stringify(updatedAttendance))
    localStorage.setItem("dailyCaptures", JSON.stringify(updatedCaptures))

    setAttendance(updatedAttendance)
    setCaptures(updatedCaptures)

    const groups = groupAttendanceByRollNumber(updatedAttendance, students)
    setAttendanceGroups(groups)

    calculateStats()
    setShowGroupDeleteConfirmDialog(false)
    setGroupToDelete(null)

    setAlert({
      type: "success",
      message: `Deleted ${attendanceRemoved} attendance records and ${capturesRemoved} capture images for group "${groupToDelete.groupName}".`,
    })
  }

  const exportGroupData = (group: AttendanceGroup) => {
    const exportData = group.attendanceRecords.map((record) => ({
      "Roll Number": record.rollNumber,
      "Student Name": record.name,
      Date: new Date(record.date).toLocaleDateString(),
      Time: record.time,
      "Capture Count": record.captureCount || 1,
      Group: group.groupName,
      "Year Batch": group.yearBatch,
      "Department Section": group.departmentSection,
    }))

    const filename = `attendance_${group.groupKey}_${new Date().toISOString().split("T")[0]}.xlsx`
    saveAsExcel(exportData, filename, `Attendance - ${group.groupName}`)

    setAlert({ type: "success", message: `Exported ${group.groupName} attendance data!` })
  }

  const exportAllGroupsData = () => {
    const allData = attendanceGroups.flatMap((group) =>
      group.attendanceRecords.map((record) => ({
        "Roll Number": record.rollNumber,
        "Student Name": record.name,
        Date: new Date(record.date).toLocaleDateString(),
        Time: record.time,
        "Capture Count": record.captureCount || 1,
        Group: group.groupName,
        "Year Batch": group.yearBatch,
        "Department Section": group.departmentSection,
      })),
    )

    const filename = `all_attendance_grouped_${new Date().toISOString().split("T")[0]}.xlsx`
    saveAsExcel(allData, filename, "All Attendance Data - Grouped")

    setAlert({ type: "success", message: "Exported all grouped attendance data!" })
  }

  const clearAllData = () => {
    localStorage.removeItem("students")
    localStorage.removeItem("attendance")
    localStorage.removeItem("dailyCaptures")

    setStudents([])
    setAttendance([])
    setCaptures([])
    setAttendanceGroups([])
    calculateStats()

    setAlert({ type: "success", message: "All data cleared successfully!" })
  }

  const getFilteredGroups = () => {
    if (selectedGroup === "all") {
      return attendanceGroups
    }
    return attendanceGroups.filter((group) => group.groupKey === selectedGroup)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <Link href="/" className="inline-flex items-center text-blue-600 hover:text-blue-800 mb-4">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Dashboard
          </Link>
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Data Management</h1>
          <p className="text-gray-600">
            Manage attendance data, cleanup old records, and organize by roll number patterns
          </p>
        </div>

        {alert && (
          <Alert
            className={`mb-6 ${
              alert.type === "success"
                ? "border-green-500 bg-green-50"
                : alert.type === "warning"
                  ? "border-yellow-500 bg-yellow-50"
                  : "border-red-500 bg-red-50"
            }`}
          >
            <AlertDescription
              className={
                alert.type === "success"
                  ? "text-green-700"
                  : alert.type === "warning"
                    ? "text-yellow-700"
                    : "text-red-700"
              }
            >
              {alert.message}
            </AlertDescription>
          </Alert>
        )}

        {/* Data Statistics */}
        {dataStats && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <Card className="bg-white shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5 text-blue-600" />
                  Students
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Total Students:</span>
                    <span className="font-bold">{dataStats.students.total}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Groups:</span>
                    <span className="font-bold">{dataStats.students.groups}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-green-600" />
                  Attendance Records
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Total Records:</span>
                    <span className="font-bold">{dataStats.attendance.total}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Last Week:</span>
                    <span className="font-bold text-green-600">{dataStats.attendance.lastWeek}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Last Month:</span>
                    <span className="font-bold text-blue-600">{dataStats.attendance.lastMonth}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Older:</span>
                    <span className="font-bold text-red-600">{dataStats.attendance.older}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Database className="h-5 w-5 text-purple-600" />
                  Capture Images
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Total Captures:</span>
                    <span className="font-bold">{dataStats.captures.total}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Last Week:</span>
                    <span className="font-bold text-green-600">{dataStats.captures.lastWeek}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Last Month:</span>
                    <span className="font-bold text-blue-600">{dataStats.captures.lastMonth}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Older:</span>
                    <span className="font-bold text-red-600">{dataStats.captures.older}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Data Cleanup Section */}
        <Card className="bg-white shadow-lg mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Trash2 className="h-5 w-5 text-red-600" />
              Data Cleanup
            </CardTitle>
            <CardDescription>Remove old attendance records and capture images to free up storage</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div>
                <Label htmlFor="cleanupDate">Remove data before</Label>
                <Input
                  id="cleanupDate"
                  type="date"
                  value={cleanupDate}
                  onChange={(e) => setCleanupDate(e.target.value)}
                />
              </div>

              <div>
                <Label htmlFor="cleanupType">Data Type</Label>
                <Select value={cleanupType} onValueChange={(value: any) => setCleanupType(value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="both">Attendance & Captures</SelectItem>
                    <SelectItem value="attendance">Attendance Only</SelectItem>
                    <SelectItem value="captures">Captures Only</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-end gap-2">
                <Button
                  onClick={() => setShowConfirmDialog(true)}
                  variant="destructive"
                  className="flex-1"
                  disabled={!cleanupDate}
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Cleanup Old Data
                </Button>
              </div>

              <div className="flex items-end">
                <Button
                  onClick={clearAllData}
                  variant="outline"
                  className="w-full border-red-500 text-red-600 hover:bg-red-50 bg-transparent"
                >
                  Clear All Data
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Attendance Groups Section */}
        <Card className="bg-white shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Filter className="h-5 w-5 text-blue-600" />
              Attendance by Roll Number Groups
            </CardTitle>
            <CardDescription>
              Attendance organized by year, department, and section based on roll number patterns
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex justify-between items-center mb-6">
              <div className="flex items-center gap-4">
                <Label htmlFor="groupFilter">Filter by Group:</Label>
                <Select value={selectedGroup} onValueChange={setSelectedGroup}>
                  <SelectTrigger className="w-64">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Groups</SelectItem>
                    {attendanceGroups.map((group) => (
                      <SelectItem key={group.groupKey} value={group.groupKey}>
                        {group.groupName}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <Button onClick={exportAllGroupsData} className="bg-green-600 hover:bg-green-700">
                <Download className="h-4 w-4 mr-2" />
                Export All Groups
              </Button>
            </div>

            <div className="space-y-4">
              {getFilteredGroups().map((group) => (
                <Card key={group.groupKey} className="border-l-4 border-l-blue-500">
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-lg">{group.groupName}</CardTitle>
                        <CardDescription>
                          Roll Pattern: {group.yearBatch}A{group.departmentSection} |{group.totalStudents} students |
                          {group.presentToday} present today ({group.attendanceRate}%)
                        </CardDescription>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          onClick={() => exportGroupData(group)}
                          size="sm"
                          variant="outline"
                          className="bg-transparent"
                        >
                          <Download className="h-4 w-4 mr-2" />
                          Export
                        </Button>
                        <Button
                          onClick={() => handleDeleteGroupData(group)} // New delete button for group
                          size="sm"
                          variant="destructive"
                          className="bg-transparent border-red-500 text-red-600 hover:bg-red-50"
                        >
                          <Trash2 className="h-4 w-4 mr-2" />
                          Delete
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div className="text-center p-3 bg-blue-50 rounded-lg">
                        <div className="text-2xl font-bold text-blue-600">{group.totalStudents}</div>
                        <div className="text-sm text-blue-800">Total Students</div>
                      </div>
                      <div className="text-center p-3 bg-green-50 rounded-lg">
                        <div className="text-2xl font-bold text-green-600">{group.presentToday}</div>
                        <div className="text-sm text-green-800">Present Today</div>
                      </div>
                      <div className="text-center p-3 bg-purple-50 rounded-lg">
                        <div className="text-2xl font-bold text-purple-600">{group.attendanceRecords.length}</div>
                        <div className="text-sm text-purple-800">Total Records</div>
                      </div>
                      <div className="text-center p-3 bg-orange-50 rounded-lg">
                        <div className="text-2xl font-bold text-orange-600">{group.attendanceRate}%</div>
                        <div className="text-sm text-orange-800">Attendance Rate</div>
                      </div>
                    </div>

                    {/* Sample students from this group */}
                    <div className="mt-4">
                      <h4 className="font-medium mb-2">Sample Students:</h4>
                      <div className="flex flex-wrap gap-2">
                        {group.students.slice(0, 5).map((student) => (
                          <span key={student.id} className="px-2 py-1 bg-gray-100 rounded text-sm">
                            {student.rollNumber} - {student.name}
                          </span>
                        ))}
                        {group.students.length > 5 && (
                          <span className="px-2 py-1 bg-gray-200 rounded text-sm">
                            +{group.students.length - 5} more
                          </span>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}

              {attendanceGroups.length === 0 && (
                <div className="text-center py-8 text-gray-500">
                  <Users className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>No attendance groups found</p>
                  <p className="text-sm">Add students with proper roll number format to see groups</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Confirmation Dialog for Date-based Cleanup */}
        {showConfirmDialog && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white p-6 rounded-lg shadow-xl max-w-md w-full mx-4">
              <div className="flex items-center gap-3 mb-4">
                <AlertTriangle className="h-6 w-6 text-red-600" />
                <h3 className="text-lg font-semibold">Confirm Data Cleanup</h3>
              </div>
              <p className="text-gray-600 mb-4">
                This will permanently remove {cleanupType} data before {new Date(cleanupDate).toLocaleDateString()}.
              </p>
              <p className="text-sm text-red-600 mb-6">
                This action cannot be undone. Make sure you have exported any important data first.
              </p>
              <div className="flex gap-3">
                <Button onClick={cleanupOldData} variant="destructive" className="flex-1">
                  <CheckCircle className="h-4 w-4 mr-2" />
                  Yes, Cleanup Data
                </Button>
                <Button onClick={() => setShowConfirmDialog(false)} variant="outline" className="flex-1">
                  Cancel
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Confirmation Dialog for Group Deletion */}
        {showGroupDeleteConfirmDialog && groupToDelete && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white p-6 rounded-lg shadow-xl max-w-md w-full mx-4">
              <div className="flex items-center gap-3 mb-4">
                <AlertTriangle className="h-6 w-6 text-red-600" />
                <h3 className="text-lg font-semibold">Confirm Group Data Deletion</h3>
              </div>
              <p className="text-gray-600 mb-4">
                This will permanently remove all attendance records and capture images for the group{" "}
                <strong>{groupToDelete.groupName}</strong>.
              </p>
              <p className="text-sm text-red-600 mb-6">
                This action cannot be undone. Make sure you have exported any important data first.
              </p>
              <div className="flex gap-3">
                <Button onClick={confirmDeleteGroupData} variant="destructive" className="flex-1">
                  <CheckCircle className="h-4 w-4 mr-2" />
                  Yes, Delete Group Data
                </Button>
                <Button onClick={() => setShowGroupDeleteConfirmDialog(false)} variant="outline" className="flex-1">
                  Cancel
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

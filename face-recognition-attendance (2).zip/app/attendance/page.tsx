"use client"

import { useState, useEffect, useRef } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import {
  Camera,
  Square,
  ArrowLeft,
  CheckCircle,
  AlertCircle,
  Eye,
  ImageIcon,
  Loader2,
  Target,
  Zap,
  Settings,
} from "lucide-react"
import Link from "next/link"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import {
  detectDetailedFacialLandmarks,
  validateEnhancedFaceGeometry,
  type EnhancedFaceGeometry,
  type DetailedFacialLandmarks,
} from "@/utils/facialLandmarks"
import { EnhancedStudentFaceDatabase } from "@/utils/studentFaceDatabase"

interface Student {
  id: string
  name: string
  rollNumber: string
  imageUrl: string
}

interface AttendanceRecord {
  name: string
  rollNumber: string
  date: string
  time: string
  firstCaptureTime: string
  captureCount: number
  captureImages: string[]
  confidenceScores: number[]
  geometryValidation: any[]
  landmarkAnalysis: any[]
}

interface CaptureLog {
  studentName: string
  rollNumber: string
  captureTime: string
  imageData: string
  confidence: number
  quality: string
  geometryScore: number
  landmarkCount: number
  qualityMetrics: any
}

// Define college start and end hours for attendance
const COLLEGE_START_HOUR = 9 // 9 AM
const COLLEGE_START_MINUTE = 30 // 9:30 AM
const COLLEGE_END_HOUR = 16 // 4 PM (16:00 in 24-hour format)
const COLLEGE_END_MINUTE = 0 // 4:00 PM

// Lunch break timing
const LUNCH_START_HOUR = 12 // 12 PM
const LUNCH_START_MINUTE = 50 // 12:50 PM
const LUNCH_END_HOUR = 13 // 1 PM
const LUNCH_END_MINUTE = 40 // 1:40 PM

export default function AttendancePage() {
  const [students, setStudents] = useState<Student[]>([])
  const [isRecording, setIsRecording] = useState(false)
  const [recognizedStudent, setRecognizedStudent] = useState<string | null>(null)
  const [todayAttendance, setTodayAttendance] = useState<AttendanceRecord[]>([])
  const [todayCaptures, setTodayCaptures] = useState<CaptureLog[]>([])
  const [alert, setAlert] = useState<{ type: "success" | "error" | "info" | "warning"; message: string } | null>(null)
  const [confirmStudent, setConfirmStudent] = useState<string | null>(null)
  const [selectedStudentCaptures, setSelectedStudentCaptures] = useState<CaptureLog[] | null>(null)
  const [isProcessing, setIsProcessing] = useState(false)
  const [currentGeometry, setCurrentGeometry] = useState<EnhancedFaceGeometry | null>(null)
  const [recognitionConfidence, setRecognitionConfidence] = useState<number>(0)
  const [lastSystemAttendanceTime, setLastSystemAttendanceTime] = useState<string | null>(null)
  const [attendanceMode, setAttendanceMode] = useState<"hourly" | "daily">("daily") // New state for attendance mode
  const [faceDatabase] = useState(() => EnhancedStudentFaceDatabase.getInstance())

  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const overlayCanvasRef = useRef<HTMLCanvasElement>(null)
  const intervalRef = useRef<NodeJS.Timeout | null>(null)

  useEffect(() => {
    const savedStudents = localStorage.getItem("students")
    const savedAttendance = localStorage.getItem("attendance")
    const savedCaptures = localStorage.getItem("dailyCaptures")
    const savedLastAttendanceTime = localStorage.getItem("lastSystemAttendanceTime")
    const savedAttendanceMode = localStorage.getItem("attendanceMode") // Load saved attendance mode

    if (savedStudents) {
      const studentsData = JSON.parse(savedStudents)
      setStudents(studentsData)

      // Initialize enhanced face database
      faceDatabase.loadFromStorage()

      // Add students to enhanced face database
      studentsData.forEach((student: Student) => {
        if (student.imageUrl) {
          faceDatabase.addStudentProfile(student, student.imageUrl)
        }
      })
    }

    if (savedAttendance) {
      const attendance = JSON.parse(savedAttendance)
      const today = new Date().toDateString()
      const todayRecords = attendance.filter(
        (record: AttendanceRecord) => new Date(record.date).toDateString() === today,
      )
      setTodayAttendance(todayRecords)
    }

    if (savedCaptures) {
      const captures = JSON.parse(savedCaptures)
      const today = new Date().toDateString()
      const todayCaptureLogs = captures.filter(
        (capture: CaptureLog) => new Date(capture.captureTime).toDateString() === today,
      )
      setTodayCaptures(todayCaptureLogs)
    }

    if (savedLastAttendanceTime) {
      setLastSystemAttendanceTime(savedLastAttendanceTime)
    }

    if (savedAttendanceMode) {
      setAttendanceMode(savedAttendanceMode as "hourly" | "daily")
    }
  }, [faceDatabase])

  useEffect(() => {
    if (alert) {
      const timer = setTimeout(() => setAlert(null), 6000)
      return () => clearTimeout(timer)
    }
  }, [alert])

  // Save attendance mode to localStorage when it changes
  useEffect(() => {
    localStorage.setItem("attendanceMode", attendanceMode)
  }, [attendanceMode])

  const captureCurrentFrame = (): string | null => {
    if (videoRef.current && canvasRef.current) {
      const canvas = canvasRef.current
      const video = videoRef.current
      canvas.width = video.videoWidth
      canvas.height = video.videoHeight

      const ctx = canvas.getContext("2d")
      if (ctx) {
        ctx.drawImage(video, 0, 0)
        return canvas.toDataURL("image/jpeg", 0.95)
      }
    }
    return null
  }

  const drawDetailedFacialLandmarks = (landmarks: DetailedFacialLandmarks, canvas: HTMLCanvasElement) => {
    try {
      const ctx = canvas.getContext("2d")
      if (!ctx || !videoRef.current) return

      const video = videoRef.current
      const scaleX = canvas.width / video.videoWidth
      const scaleY = canvas.height / video.videoHeight

      ctx.clearRect(0, 0, canvas.width, canvas.height)

      // Draw face contour (green dots)
      ctx.fillStyle = "#10B981"
      landmarks.faceContour.forEach((point) => {
        ctx.beginPath()
        ctx.arc(point.x * scaleX, point.y * scaleY, 3, 0, 2 * Math.PI)
        ctx.fill()
      })

      // Draw forehead points (green dots)
      landmarks.forehead.forEach((point) => {
        ctx.beginPath()
        ctx.arc(point.x * scaleX, point.y * scaleY, 3, 0, 2 * Math.PI)
        ctx.fill()
      })

      // Draw chin points (green dots)
      landmarks.chin.forEach((point) => {
        ctx.beginPath()
        ctx.arc(point.x * scaleX, point.y * scaleY, 3, 0, 2 * Math.PI)
        ctx.fill()
      })

      // Draw eye landmarks (blue dots)
      ctx.fillStyle = "#3B82F6"

      // Left eye
      ctx.beginPath()
      ctx.arc(landmarks.leftEye.center.x * scaleX, landmarks.leftEye.center.y * scaleY, 4, 0, 2 * Math.PI)
      ctx.fill()
      ;[landmarks.leftEye.innerCorner, landmarks.leftEye.outerCorner].forEach((corner) => {
        ctx.beginPath()
        ctx.arc(corner.x * scaleX, corner.y * scaleY, 2, 0, 2 * Math.PI)
        ctx.fill()
      })

      landmarks.leftEye.upperLid.concat(landmarks.leftEye.lowerLid).forEach((point) => {
        ctx.beginPath()
        ctx.arc(point.x * scaleX, point.y * scaleY, 2, 0, 2 * Math.PI)
        ctx.fill()
      })

      // Right eye
      ctx.beginPath()
      ctx.arc(landmarks.rightEye.center.x * scaleX, landmarks.rightEye.center.y * scaleY, 4, 0, 2 * Math.PI)
      ctx.fill()
      ;[landmarks.rightEye.innerCorner, landmarks.rightEye.outerCorner].forEach((corner) => {
        ctx.beginPath()
        ctx.arc(corner.x * scaleX, corner.y * scaleY, 2, 0, 2 * Math.PI)
        ctx.fill()
      })

      landmarks.rightEye.upperLid.concat(landmarks.rightEye.lowerLid).forEach((point) => {
        ctx.beginPath()
        ctx.arc(point.x * scaleX, point.y * scaleY, 2, 0, 2 * Math.PI)
        ctx.fill()
      })

      // Draw eyebrows (blue dots)
      landmarks.leftEyebrow.concat(landmarks.rightEyebrow).forEach((point) => {
        ctx.beginPath()
        ctx.arc(point.x * scaleX, point.y * scaleY, 2, 0, 2 * Math.PI)
        ctx.fill()
      })

      // Draw nose landmarks (orange dots)
      ctx.fillStyle = "#F97316"

      // Nose tip
      ctx.beginPath()
      ctx.arc(landmarks.nose.tip.x * scaleX, landmarks.nose.tip.y * scaleY, 4, 0, 2 * Math.PI)
      ctx.fill()

      // Nose bridge
      landmarks.nose.bridge.forEach((point) => {
        ctx.beginPath()
        ctx.arc(point.x * scaleX, point.y * scaleY, 2, 0, 2 * Math.PI)
        ctx.fill()
      })

      // Nostrils and wings
      ;[
        landmarks.nose.leftNostril,
        landmarks.nose.rightNostril,
        landmarks.nose.leftWing,
        landmarks.nose.rightWing,
      ].forEach((point) => {
        ctx.beginPath()
        ctx.arc(point.x * scaleX, point.y * scaleY, 2, 0, 2 * Math.PI)
        ctx.fill()
      })

      // Draw mouth landmarks (red dots)
      ctx.fillStyle = "#EF4444"
      ;[landmarks.mouth.leftCorner, landmarks.mouth.rightCorner, landmarks.mouth.center].forEach((point) => {
        ctx.beginPath()
        ctx.arc(point.x * scaleX, point.y * scaleY, 3, 0, 2 * Math.PI)
        ctx.fill()
      })

      // Lip contours
      landmarks.mouth.upperLipTop
        .concat(landmarks.mouth.upperLipBottom)
        .concat(landmarks.mouth.lowerLipTop)
        .concat(landmarks.mouth.lowerLipBottom)
        .forEach((point) => {
          ctx.beginPath()
          ctx.arc(point.x * scaleX, point.y * scaleY, 2, 0, 2 * Math.PI)
          ctx.fill()
        })

      // Draw connecting lines for better visualization
      ctx.strokeStyle = "#10B981"
      ctx.lineWidth = 1

      // Eye to eye line
      ctx.beginPath()
      ctx.moveTo(landmarks.leftEye.center.x * scaleX, landmarks.leftEye.center.y * scaleY)
      ctx.lineTo(landmarks.rightEye.center.x * scaleX, landmarks.rightEye.center.y * scaleY)
      ctx.stroke()

      // Nose to mouth line
      ctx.beginPath()
      ctx.moveTo(landmarks.nose.tip.x * scaleX, landmarks.nose.tip.y * scaleY)
      ctx.lineTo(landmarks.mouth.center.x * scaleX, landmarks.mouth.center.y * scaleY)
      ctx.stroke()

      // Face symmetry line
      ctx.strokeStyle = "#10B981"
      ctx.setLineDash([5, 5])
      ctx.beginPath()
      ctx.moveTo(landmarks.forehead[2].x * scaleX, landmarks.forehead[2].y * scaleY)
      ctx.lineTo(landmarks.chin[1].x * scaleX, landmarks.chin[1].y * scaleY)
      ctx.stroke()
      ctx.setLineDash([])
    } catch (error) {
      console.error("Error drawing detailed facial landmarks:", error)
    }
  }

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          width: { ideal: 1280 },
          height: { ideal: 720 },
          facingMode: "user",
        },
      })
      if (videoRef.current) {
        videoRef.current.srcObject = stream
        setIsRecording(true)
        startEnhancedFaceRecognition()
      }
    } catch (error) {
      setAlert({ type: "error", message: "Failed to access camera. Please check permissions." })
    }
  }

  const stopCamera = () => {
    if (videoRef.current?.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream
      stream.getTracks().forEach((track) => track.stop())
      videoRef.current.srcObject = null
    }
    setIsRecording(false)
    setRecognizedStudent(null)
    setCurrentGeometry(null)
    setIsProcessing(false)
    if (intervalRef.current) {
      clearInterval(intervalRef.current)
    }

    // Clear overlay
    if (overlayCanvasRef.current) {
      const ctx = overlayCanvasRef.current.getContext("2d")
      if (ctx) {
        ctx.clearRect(0, 0, overlayCanvasRef.current.width, overlayCanvasRef.current.height)
      }
    }
  }

  const startEnhancedFaceRecognition = () => {
    intervalRef.current = setInterval(async () => {
      if (isProcessing) return

      const now = new Date()
      const currentHour = now.getHours()
      const todayDate = now.toISOString().split("T")[0]

      // Check if within college hours and not during lunch break
      const currentTime = now.getHours() * 60 + now.getMinutes() // Convert to minutes
      const collegeStart = COLLEGE_START_HOUR * 60 + COLLEGE_START_MINUTE
      const collegeEnd = COLLEGE_END_HOUR * 60 + COLLEGE_END_MINUTE
      const lunchStart = LUNCH_START_HOUR * 60 + LUNCH_START_MINUTE
      const lunchEnd = LUNCH_END_HOUR * 60 + LUNCH_END_MINUTE

      if (currentTime < collegeStart || currentTime >= collegeEnd) {
        setAlert({
          type: "warning",
          message: `Attendance can only be taken between ${COLLEGE_START_HOUR}:${COLLEGE_START_MINUTE.toString().padStart(2, "0")} and ${COLLEGE_END_HOUR}:${COLLEGE_END_MINUTE.toString().padStart(2, "0")}.`,
        })
        setIsProcessing(false)
        return
      }

      // Check if during lunch break
      if (currentTime >= lunchStart && currentTime < lunchEnd) {
        setAlert({
          type: "warning",
          message: `Attendance is not available during lunch break (${LUNCH_START_HOUR}:${LUNCH_START_MINUTE.toString().padStart(2, "0")} - ${LUNCH_END_HOUR}:${LUNCH_END_MINUTE.toString().padStart(2, "0")}).`,
        })
        setIsProcessing(false)
        return
      }

      // Check attendance mode restrictions
      if (attendanceMode === "hourly") {
        // Check if attendance has already been processed for the current hour slot
        if (lastSystemAttendanceTime) {
          const lastAttendanceDate = new Date(lastSystemAttendanceTime).toISOString().split("T")[0]
          const lastAttendanceHour = new Date(lastSystemAttendanceTime).getHours()

          if (lastAttendanceDate === todayDate && lastAttendanceHour === currentHour) {
            setAlert({
              type: "info",
              message: `Hourly attendance already processed for this hour (${currentHour}:00 - ${currentHour + 1}:00). Please wait for the next hour.`,
            })
            setIsProcessing(false)
            return
          }
        }
      }
      // For daily mode, no additional time restrictions beyond college hours

      const imageData = captureCurrentFrame()
      if (!imageData) return

      setIsProcessing(true)

      try {
        // Step 1: Detect detailed facial landmarks
        const geometry = await detectDetailedFacialLandmarks(imageData)
        if (!geometry) {
          setAlert({
            type: "warning",
            message:
              "No comprehensive facial landmarks detected. Please position your face clearly and ensure good lighting.",
          })
          setIsProcessing(false)
          return
        }

        setCurrentGeometry(geometry)

        // Step 2: Validate enhanced face geometry
        const validation = validateEnhancedFaceGeometry(geometry)
        if (!validation.isValid) {
          setAlert({
            type: "warning",
            message: `Enhanced validation failed: ${validation.issues.join(", ")} (${geometry.landmarkCount} landmarks detected)`,
          })
          setIsProcessing(false)
          return
        }

        // Step 3: Draw detailed facial landmarks
        if (overlayCanvasRef.current) {
          overlayCanvasRef.current.width = videoRef.current?.clientWidth || 640
          overlayCanvasRef.current.height = videoRef.current?.clientHeight || 480
          drawDetailedFacialLandmarks(geometry.landmarks, overlayCanvasRef.current)
        }

        // Step 4: Enhanced student identification
        const identification = await faceDatabase.identifyStudent(imageData)

        if (identification.student && identification.confidence > 0.88) {
          setRecognizedStudent(identification.student.name)
          setRecognitionConfidence(identification.confidence)

          // Strict quality requirements for attendance
          if (validation.qualityScore < 0.85 || validation.landmarkCoverage < 0.8) {
            setAlert({
              type: "warning",
              message: `${identification.student.name} detected but quality insufficient (${Math.round(validation.qualityScore * 100)}% quality, ${Math.round(validation.landmarkCoverage * 100)}% landmarks). Please improve positioning.`,
            })
            setIsProcessing(false)
            return
          }

          setTimeout(() => {
            captureStudentImage(
              identification.student!.name,
              identification.confidence,
              validation.qualityScore,
              geometry,
              identification.landmarkAnalysis,
            )
          }, 2000)
        } else if (identification.confidence > 0.7) {
          setAlert({
            type: "warning",
            message: `Uncertain match (${Math.round(identification.confidence * 100)}%, ${identification.landmarkAnalysis?.detectedLandmarks || 0} landmarks). Please face camera directly with good lighting.`,
          })
        } else {
          setAlert({
            type: "info",
            message: `Face detected with ${geometry.landmarkCount} landmarks but no matching student found. Please ensure you are registered.`,
          })
        }
      } catch (error) {
        console.error("Enhanced face recognition error:", error)
        setAlert({ type: "error", message: "Enhanced face recognition processing failed" })
      }

      setIsProcessing(false)
    }, 4500) // Increased interval for comprehensive processing
  }

  const captureStudentImage = async (
    studentName: string,
    confidence: number,
    qualityScore: number,
    geometry: EnhancedFaceGeometry,
    landmarkAnalysis: any,
  ) => {
    const student = students.find((s) => s.name === studentName)
    if (!student) return

    const now = new Date()
    const captureTime = now.toISOString()

    const existingAttendance = todayAttendance.find((record) => record.name === studentName)

    // Check attendance mode restrictions
    if (attendanceMode === "daily") {
      // If student is already marked present today, do not capture new image or update attendance
      if (existingAttendance) {
        setAlert({ type: "info", message: `${studentName} is already marked present today (Daily mode).` })
        setRecognizedStudent(null)
        setRecognitionConfidence(0)
        return
      }
    } else if (attendanceMode === "hourly") {
      // For hourly mode, check if student was already marked in this hour
      if (existingAttendance) {
        const lastAttendanceHour = new Date(existingAttendance.firstCaptureTime).getHours()
        const currentHour = now.getHours()

        if (lastAttendanceHour === currentHour) {
          setAlert({
            type: "info",
            message: `${studentName} is already marked present for this hour (${currentHour}:00 - ${currentHour + 1}:00).`,
          })
          setRecognizedStudent(null)
          setRecognitionConfidence(0)
          return
        }
      }
    }

    // Proceed with capture and attendance marking
    const imageData = captureCurrentFrame()
    if (!imageData) {
      setAlert({ type: "error", message: "Failed to capture high-quality image" })
      setRecognizedStudent(null)
      return
    }

    // Very strict validation for attendance marking
    if (confidence < 0.92 || qualityScore < 0.85 || geometry.landmarkCount < 50) {
      setAlert({
        type: "warning",
        message: `${studentName} recognition insufficient (${Math.round(confidence * 100)}% confidence, ${Math.round(qualityScore * 100)}% quality, ${geometry.landmarkCount} landmarks). Please optimize positioning.`,
      })
      setRecognizedStudent(null)
      return
    }

    const newCapture: CaptureLog = {
      studentName: student.name,
      rollNumber: student.rollNumber,
      captureTime: captureTime,
      imageData: imageData,
      confidence: confidence,
      quality: qualityScore > 0.95 ? "excellent" : qualityScore > 0.85 ? "good" : "fair",
      geometryScore: qualityScore,
      landmarkCount: geometry.landmarkCount,
      qualityMetrics: geometry.qualityMetrics,
    }

    const updatedCaptures = [...todayCaptures, newCapture]
    setTodayCaptures(updatedCaptures)

    const savedCaptures = localStorage.getItem("dailyCaptures")
    const allCaptures = savedCaptures ? JSON.parse(savedCaptures) : []
    allCaptures.push(newCapture)
    localStorage.setItem("dailyCaptures", JSON.stringify(allCaptures))

    // Add to enhanced face database
    await faceDatabase.addStudentProfile(student, imageData)

    // Mark attendance
    if (attendanceMode === "daily" || !existingAttendance) {
      // For daily mode or first attendance of the day in hourly mode
      markAttendance(
        studentName,
        captureTime,
        [imageData],
        [confidence],
        [{ confidence, qualityScore, geometry }],
        [landmarkAnalysis],
      )
      setAlert({
        type: "success",
        message: `✓ ${studentName} verified present! (${attendanceMode === "hourly" ? "Hour " + now.getHours() : "Daily"} - ${Math.round(confidence * 100)}% confidence, ${geometry.landmarkCount} landmarks)`,
      })
    } else {
      // For hourly mode, update existing attendance with new hour
      updateAttendanceWithCapture(
        studentName,
        imageData,
        confidence,
        { confidence, qualityScore, geometry },
        landmarkAnalysis,
      )
      setAlert({
        type: "success",
        message: `✓ ${studentName} verified present for hour ${now.getHours()}! (${Math.round(confidence * 100)}% confidence, ${geometry.landmarkCount} landmarks)`,
      })
    }

    // Update last system attendance time (for hourly mode)
    if (attendanceMode === "hourly") {
      setLastSystemAttendanceTime(captureTime)
      localStorage.setItem("lastSystemAttendanceTime", captureTime)
    }

    setRecognizedStudent(null)
    setRecognitionConfidence(0)
  }

  const markAttendance = (
    studentName: string,
    captureTime: string,
    captureImages: string[],
    confidenceScores: number[],
    geometryValidation: any[],
    landmarkAnalysis: any[],
  ) => {
    const today = new Date()
    const dateStr = today.toISOString().split("T")[0]
    const timeStr = new Date(captureTime).toLocaleTimeString()

    const student = students.find((s) => s.name === studentName)
    if (!student) return

    const newRecord: AttendanceRecord = {
      name: studentName,
      rollNumber: student.rollNumber,
      date: dateStr,
      time: timeStr,
      firstCaptureTime: captureTime,
      captureCount: 1,
      captureImages: captureImages,
      confidenceScores: confidenceScores,
      geometryValidation: geometryValidation,
      landmarkAnalysis: landmarkAnalysis,
    }

    const updatedTodayAttendance = [...todayAttendance, newRecord]
    setTodayAttendance(updatedTodayAttendance)

    const savedAttendance = localStorage.getItem("attendance")
    const allAttendance = savedAttendance ? JSON.parse(savedAttendance) : []
    allAttendance.push(newRecord)
    localStorage.setItem("attendance", JSON.stringify(allAttendance))
  }

  const updateAttendanceWithCapture = (
    studentName: string,
    newImageData: string,
    confidence: number,
    geometryValidation: any,
    landmarkAnalysis: any,
  ) => {
    const updatedTodayAttendance = todayAttendance.map((record) => {
      if (record.name === studentName) {
        return {
          ...record,
          captureCount: record.captureCount + 1,
          captureImages: [...record.captureImages, newImageData],
          confidenceScores: [...(record.confidenceScores || []), confidence],
          geometryValidation: [...(record.geometryValidation || []), geometryValidation],
          landmarkAnalysis: [...(record.landmarkAnalysis || []), landmarkAnalysis],
        }
      }
      return record
    })
    setTodayAttendance(updatedTodayAttendance)

    const savedAttendance = localStorage.getItem("attendance")
    const allAttendance = savedAttendance ? JSON.parse(savedAttendance) : []
    const updatedAllAttendance = allAttendance.map((record: AttendanceRecord) => {
      if (record.name === studentName && record.date === new Date().toISOString().split("T")[0]) {
        return {
          ...record,
          captureCount: record.captureCount + 1,
          captureImages: [...record.captureImages, newImageData],
          confidenceScores: [...(record.confidenceScores || []), confidence],
          geometryValidation: [...(record.geometryValidation || []), geometryValidation],
          landmarkAnalysis: [...(record.landmarkAnalysis || []), landmarkAnalysis],
        }
      }
      return record
    })
    localStorage.setItem("attendance", JSON.stringify(updatedAllAttendance))
  }

  const manualMarkAttendance = (studentName: string) => {
    const alreadyPresent = todayAttendance.some((record) => record.name === studentName)

    if (attendanceMode === "daily" && alreadyPresent) {
      setAlert({ type: "error", message: `${studentName} is already marked present today (Daily mode)` })
      return
    }

    if (attendanceMode === "hourly" && alreadyPresent) {
      const existingRecord = todayAttendance.find((record) => record.name === studentName)
      const currentHour = new Date().getHours()
      const lastAttendanceHour = new Date(existingRecord!.firstCaptureTime).getHours()

      if (lastAttendanceHour === currentHour) {
        setAlert({
          type: "error",
          message: `${studentName} is already marked present for this hour (${currentHour}:00 - ${currentHour + 1}:00)`,
        })
        return
      }
    }

    setConfirmStudent(studentName)
  }

  const confirmMarkAttendance = () => {
    if (confirmStudent) {
      const now = new Date().toISOString()
      const currentHour = new Date().getHours()

      if (attendanceMode === "daily" || !todayAttendance.some((record) => record.name === confirmStudent)) {
        markAttendance(
          confirmStudent,
          now,
          [],
          [1.0],
          [{ confidence: 1.0, qualityScore: 1.0, manual: true }],
          [{ manual: true, landmarkCount: 0 }],
        )
        setAlert({
          type: "success",
          message: `${confirmStudent} marked present manually! (${attendanceMode === "hourly" ? "Hour " + currentHour : "Daily"})`,
        })
      } else {
        // Update existing record for hourly mode
        updateAttendanceWithCapture(
          confirmStudent,
          "",
          1.0,
          { confidence: 1.0, qualityScore: 1.0, manual: true },
          { manual: true, landmarkCount: 0 },
        )
        setAlert({
          type: "success",
          message: `${confirmStudent} marked present manually for hour ${currentHour}!`,
        })
      }
      setConfirmStudent(null)
    }
  }

  const viewStudentCaptures = (studentName: string) => {
    const studentCaptures = todayCaptures.filter((capture) => capture.studentName === studentName)
    setSelectedStudentCaptures(studentCaptures)
  }

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 0.92) return "text-green-600"
    if (confidence >= 0.85) return "text-blue-600"
    if (confidence >= 0.75) return "text-yellow-600"
    return "text-red-600"
  }

  const getQualityColor = (quality: string | number) => {
    const score =
      typeof quality === "string"
        ? quality === "excellent"
          ? 1
          : quality === "good"
            ? 0.85
            : quality === "fair"
              ? 0.7
              : 0.5
        : quality

    if (score >= 0.95) return "text-green-600"
    if (score >= 0.85) return "text-blue-600"
    if (score >= 0.7) return "text-yellow-600"
    return "text-red-600"
  }

  const getLandmarkColor = (count: number) => {
    if (count >= 60) return "text-green-600"
    if (count >= 50) return "text-blue-600"
    if (count >= 40) return "text-yellow-600"
    return "text-red-600"
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <Link href="/" className="inline-flex items-center text-blue-600 hover:text-blue-800 mb-4">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Dashboard
          </Link>
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Enhanced Facial Landmark Recognition</h1>
          <p className="text-gray-600">Comprehensive 68-point facial landmark detection for maximum accuracy</p>
        </div>

        {alert && (
          <Alert
            className={`mb-6 ${
              alert.type === "success"
                ? "border-green-500 bg-green-50"
                : alert.type === "info"
                  ? "border-blue-500 bg-blue-50"
                  : alert.type === "warning"
                    ? "border-yellow-500 bg-yellow-50"
                    : "border-red-500 bg-red-50"
            }`}
          >
            <AlertDescription
              className={
                alert.type === "success"
                  ? "text-green-700"
                  : alert.type === "info"
                    ? "text-blue-700"
                    : alert.type === "warning"
                      ? "text-yellow-700"
                      : "text-red-700"
              }
            >
              {alert.message}
            </AlertDescription>
          </Alert>
        )}

        {/* Attendance Mode Selection */}
        <Card className="bg-white shadow-lg mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Settings className="h-5 w-5 text-blue-600" />
              Attendance Mode Settings
            </CardTitle>
            <CardDescription>Choose how attendance should be tracked - once per day or hourly</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-4">
              <Label htmlFor="attendanceMode">Attendance Mode:</Label>
              <Select value={attendanceMode} onValueChange={(value: "hourly" | "daily") => setAttendanceMode(value)}>
                <SelectTrigger className="w-64">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="daily">Daily (Once per day)</SelectItem>
                  <SelectItem value="hourly">Hourly (Multiple times per day)</SelectItem>
                </SelectContent>
              </Select>
              <div className="text-sm text-gray-600">
                {attendanceMode === "daily"
                  ? "Students can only be marked present once per day"
                  : "Students can be marked present once per hour (9:30 AM - 4:00 PM, excluding lunch break 12:50 - 1:40 PM)"}
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Camera Feed */}
          <div className="lg:col-span-2">
            <Card className="bg-white shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Camera className="h-5 w-5" />
                  Enhanced Landmark Detection
                  {isProcessing && <Loader2 className="h-4 w-4 animate-spin text-blue-600" />}
                </CardTitle>
                <CardDescription>
                  68-point facial landmark mapping with comprehensive geometric analysis ({attendanceMode} mode)
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="relative">
                  <video
                    ref={videoRef}
                    autoPlay
                    muted
                    className="w-full rounded-lg bg-gray-900"
                    style={{ aspectRatio: "16/9" }}
                  />

                  {/* Enhanced facial landmarks overlay */}
                  <canvas
                    ref={overlayCanvasRef}
                    className="absolute top-0 left-0 w-full h-full pointer-events-none rounded-lg"
                  />

                  {recognizedStudent && (
                    <div className="absolute top-4 left-4 bg-green-500 text-white px-4 py-2 rounded-lg font-medium">
                      <div className="flex items-center gap-2">
                        <Zap className="h-4 w-4" />
                        <span>✓ Verified: {recognizedStudent}</span>
                      </div>
                      <div className="text-xs opacity-90">Confidence: {Math.round(recognitionConfidence * 100)}%</div>
                      <div className="text-xs opacity-90">Mode: {attendanceMode}</div>
                      <div className="text-xs opacity-90">Processing comprehensive landmarks...</div>
                    </div>
                  )}

                  {currentGeometry && (
                    <div className="absolute top-4 right-4 bg-black bg-opacity-75 text-white px-3 py-2 rounded-lg text-sm">
                      <div className="flex items-center gap-2 mb-1">
                        <Target className="h-3 w-3" />
                        <span>Landmark Analysis</span>
                      </div>
                      <div>
                        Quality:{" "}
                        <span className={getQualityColor(currentGeometry.confidence)}>
                          {Math.round(currentGeometry.confidence * 100)}%
                        </span>
                      </div>
                      <div>
                        Landmarks:{" "}
                        <span className={getLandmarkColor(currentGeometry.landmarkCount)}>
                          {currentGeometry.landmarkCount}/68
                        </span>
                      </div>
                      <div className="text-xs opacity-75">
                        Symmetry: {Math.round(currentGeometry.qualityMetrics.symmetry * 100)}%
                      </div>
                      <div className="text-xs opacity-75">
                        Clarity: {Math.round(currentGeometry.qualityMetrics.clarity * 100)}%
                      </div>
                    </div>
                  )}

                  {!isRecording && (
                    <div className="absolute inset-0 flex items-center justify-center bg-gray-900 bg-opacity-50 rounded-lg">
                      <div className="text-center text-white">
                        <Camera className="h-12 w-12 mx-auto mb-4 opacity-50" />
                        <p className="text-lg">Enhanced Recognition Ready</p>
                        <p className="text-sm opacity-75">68-point facial landmark detection system</p>
                        <p className="text-sm opacity-75">Mode: {attendanceMode}</p>
                        <p className="text-sm opacity-75">Hours: 9:30 AM - 4:00 PM (Lunch: 12:50 - 1:40 PM excluded)</p>
                      </div>
                    </div>
                  )}
                </div>

                <div className="flex gap-4 mt-4">
                  {!isRecording ? (
                    <Button onClick={startCamera} className="flex-1 bg-green-600 hover:bg-green-700">
                      <Camera className="h-4 w-4 mr-2" />
                      Start Enhanced Recognition
                    </Button>
                  ) : (
                    <Button onClick={stopCamera} variant="destructive" className="flex-1">
                      <Square className="h-4 w-4 mr-2" />
                      Stop Recognition
                    </Button>
                  )}
                </div>

                {/* Enhanced Recognition Guide */}
                <div className="mt-4 p-4 bg-blue-50 rounded-lg">
                  <h4 className="font-medium text-blue-900 mb-3 flex items-center gap-2">
                    <img src="/images/user-face-landmarks.png" alt="Landmark Reference" className="w-6 h-6" />
                    68-Point Landmark Detection Guide ({attendanceMode} mode):
                  </h4>
                  <div className="grid grid-cols-2 gap-4 text-sm text-blue-800">
                    <div>
                      <strong>Landmark Colors:</strong>
                      <ul className="mt-1 space-y-1">
                        <li>
                          • <span className="text-green-600">Green:</span> Face contour, forehead, chin
                        </li>
                        <li>
                          • <span className="text-blue-600">Blue:</span> Eyes and eyebrows
                        </li>
                        <li>
                          • <span className="text-orange-600">Orange:</span> Nose features
                        </li>
                        <li>
                          • <span className="text-red-600">Red:</span> Mouth and lips
                        </li>
                      </ul>
                    </div>
                    <div>
                      <strong>Quality Requirements:</strong>
                      <ul className="mt-1 space-y-1">
                        <li>• 50+ landmarks detected</li>
                        <li>• 92%+ recognition confidence</li>
                        <li>• 85%+ image quality</li>
                        <li>• Good facial symmetry</li>
                        <li>
                          •{" "}
                          {attendanceMode === "daily"
                            ? "Once per day"
                            : "Once per hour (9:30 AM - 4:00 PM, excluding lunch)"}
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Enhanced Capture Analytics */}
            <Card className="bg-white shadow-lg mt-6">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <ImageIcon className="h-5 w-5 text-blue-600" />
                  Enhanced Landmark Analytics
                </CardTitle>
                <CardDescription>
                  Comprehensive facial analysis results - Total captures: {todayCaptures.length} ({attendanceMode} mode)
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {students.map((student) => {
                    const studentCaptures = todayCaptures.filter((capture) => capture.studentName === student.name)
                    const isPresent = todayAttendance.some((record) => record.name === student.name)
                    const avgConfidence =
                      studentCaptures.length > 0
                        ? studentCaptures.reduce((sum, cap) => sum + cap.confidence, 0) / studentCaptures.length
                        : 0
                    const avgLandmarks =
                      studentCaptures.length > 0
                        ? studentCaptures.reduce((sum, cap) => sum + cap.landmarkCount, 0) / studentCaptures.length
                        : 0
                    const avgGeometry =
                      studentCaptures.length > 0
                        ? studentCaptures.reduce((sum, cap) => sum + cap.geometryScore, 0) / studentCaptures.length
                        : 0

                    return (
                      <div
                        key={student.id}
                        className={`p-3 rounded-lg border ${
                          isPresent ? "bg-green-50 border-green-200" : "bg-gray-50 border-gray-200"
                        }`}
                      >
                        <div className="text-sm font-medium">{student.name}</div>
                        <div className="text-xs text-gray-500">Roll: {student.rollNumber}</div>
                        <div className="flex items-center justify-between mt-2">
                          <div className="text-xs">
                            <div>
                              {studentCaptures.length} capture{studentCaptures.length !== 1 ? "s" : ""}
                            </div>
                            {avgConfidence > 0 && (
                              <div className={getConfidenceColor(avgConfidence)}>
                                ID: {Math.round(avgConfidence * 100)}%
                              </div>
                            )}
                            {avgLandmarks > 0 && (
                              <div className={getLandmarkColor(avgLandmarks)}>LM: {Math.round(avgLandmarks)}</div>
                            )}
                            {avgGeometry > 0 && (
                              <div className={getQualityColor(avgGeometry)}>Geo: {Math.round(avgGeometry * 100)}%</div>
                            )}
                          </div>
                          {studentCaptures.length > 0 && (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => viewStudentCaptures(student.name)}
                              className="text-xs px-2 py-1 h-6"
                            >
                              <Eye className="h-3 w-3" />
                            </Button>
                          )}
                        </div>
                      </div>
                    )
                  })}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Enhanced Attendance */}
            <Card className="bg-white shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5 text-green-600" />
                  Landmark-Verified Attendance
                </CardTitle>
                <CardDescription>
                  {todayAttendance.length} students verified with landmarks ({attendanceMode} mode)
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 max-h-64 overflow-y-auto">
                  {todayAttendance.map((record, index) => {
                    const avgConfidence =
                      record.confidenceScores && record.confidenceScores.length > 0
                        ? record.confidenceScores.reduce((sum, score) => sum + score, 0) /
                          record.confidenceScores.length
                        : 1.0

                    const avgLandmarks =
                      record.landmarkAnalysis && record.landmarkAnalysis.length > 0
                        ? record.landmarkAnalysis.reduce(
                            (sum: number, analysis: any) => sum + (analysis.detectedLandmarks || 0),
                            0,
                          ) / record.landmarkAnalysis.length
                        : 0

                    const avgGeometry =
                      record.geometryValidation && record.geometryValidation.length > 0
                        ? record.geometryValidation.reduce(
                            (sum: number, val: any) => sum + (val.qualityScore || 1),
                            0,
                          ) / record.geometryValidation.length
                        : 1.0

                    return (
                      <div key={index} className="flex justify-between items-center p-2 bg-green-50 rounded">
                        <div>
                          <span className="font-medium text-green-800">{record.name}</span>
                          <div className="text-xs text-green-600">
                            {record.captureCount} verification{record.captureCount !== 1 ? "s" : ""}
                            {avgConfidence < 1.0 && (
                              <span className={`ml-2 ${getConfidenceColor(avgConfidence)}`}>
                                ID: {Math.round(avgConfidence * 100)}%
                              </span>
                            )}
                            {avgLandmarks > 0 && (
                              <span className={`ml-2 ${getLandmarkColor(avgLandmarks)}`}>
                                LM: {Math.round(avgLandmarks)}
                              </span>
                            )}
                            {avgGeometry < 1.0 && (
                              <span className={`ml-2 ${getQualityColor(avgGeometry)}`}>
                                Geo: {Math.round(avgGeometry * 100)}%
                              </span>
                            )}
                          </div>
                        </div>
                        <span className="text-sm text-green-600">{record.time}</span>
                      </div>
                    )
                  })}
                  {todayAttendance.length === 0 && (
                    <div className="text-center py-4 text-gray-500">No landmark-verified attendance yet</div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Manual Attendance */}
            <Card className="bg-white shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertCircle className="h-5 w-5 text-orange-600" />
                  Manual Override
                </CardTitle>
                <CardDescription>Manual attendance marking if needed ({attendanceMode} mode)</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 max-h-64 overflow-y-auto">
                  {students.map((student) => {
                    const isPresent = todayAttendance.some((record) => record.name === student.name)
                    const presentRecord = todayAttendance.find((record) => record.name === student.name)
                    const currentHour = new Date().getHours()

                    // For hourly mode, check if present in current hour
                    const isPresentThisHour =
                      attendanceMode === "hourly" && presentRecord
                        ? new Date(presentRecord.firstCaptureTime).getHours() === currentHour
                        : isPresent

                    return (
                      <div
                        key={student.id}
                        className={`flex justify-between items-center p-2 border rounded ${
                          (attendanceMode === "daily" && isPresent) ||
                          (attendanceMode === "hourly" && isPresentThisHour)
                            ? "bg-green-50 border-green-200"
                            : "bg-white"
                        }`}
                      >
                        <div>
                          <span className="font-medium">{student.name}</span>
                          <div className="text-xs text-gray-500">Roll: {student.rollNumber}</div>
                          {isPresent && presentRecord && (
                            <div className="text-xs text-green-600">
                              Verified at {presentRecord.time} ({presentRecord.captureCount} captures)
                              {attendanceMode === "hourly" && (
                                <div>Hour: {new Date(presentRecord.firstCaptureTime).getHours()}:00</div>
                              )}
                            </div>
                          )}
                        </div>
                        {(attendanceMode === "daily" && isPresent) ||
                        (attendanceMode === "hourly" && isPresentThisHour) ? (
                          <div className="flex items-center gap-1">
                            <CheckCircle className="h-4 w-4 text-green-600" />
                            <span className="text-green-600 text-sm font-medium">
                              {attendanceMode === "hourly" ? `H${currentHour}` : "Present"}
                            </span>
                          </div>
                        ) : (
                          <Button
                            size="sm"
                            onClick={() => manualMarkAttendance(student.name)}
                            className="bg-blue-600 hover:bg-blue-700"
                          >
                            Mark
                          </Button>
                        )}
                      </div>
                    )
                  })}
                  {students.length === 0 && (
                    <div className="text-center py-4 text-gray-500">
                      <Link href="/students" className="text-blue-600 hover:underline">
                        Add students first
                      </Link>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Confirmation Dialog */}
        {confirmStudent && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white p-6 rounded-lg shadow-xl max-w-sm w-full mx-4">
              <h3 className="text-lg font-semibold mb-4">Confirm Manual Attendance</h3>
              <p className="text-gray-600 mb-6">
                Manually mark <strong>{confirmStudent}</strong> as present for{" "}
                {attendanceMode === "hourly" ? `hour ${new Date().getHours()}` : "today"}?
              </p>
              <div className="flex gap-3">
                <Button onClick={confirmMarkAttendance} className="flex-1 bg-green-600 hover:bg-green-700">
                  Yes, Mark Present
                </Button>
                <Button onClick={() => setConfirmStudent(null)} variant="outline" className="flex-1">
                  Cancel
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Enhanced Captures Viewer Dialog */}
        {selectedStudentCaptures && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white p-6 rounded-lg shadow-xl max-w-4xl w-full mx-4 max-h-[80vh] overflow-y-auto">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-semibold">
                  Enhanced Landmark Analysis: {selectedStudentCaptures[0]?.studentName} (
                  {selectedStudentCaptures.length} captures - {attendanceMode} mode)
                </h3>
                <Button onClick={() => setSelectedStudentCaptures(null)} variant="outline" size="sm">
                  Close
                </Button>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {selectedStudentCaptures.map((capture, index) => (
                  <div key={index} className="border rounded-lg p-2">
                    <img
                      src={capture.imageData || "/placeholder.svg"}
                      alt={`Capture ${index + 1}`}
                      className="w-full h-32 object-cover rounded"
                    />
                    <div className="text-xs text-gray-500 mt-1">
                      <div>{new Date(capture.captureTime).toLocaleTimeString()}</div>
                      <div>Hour: {new Date(capture.captureTime).getHours()}:00</div>
                      <div className={getConfidenceColor(capture.confidence)}>
                        ID Confidence: {Math.round(capture.confidence * 100)}%
                      </div>
                      <div className={getLandmarkColor(capture.landmarkCount)}>
                        Landmarks: {capture.landmarkCount}/68
                      </div>
                      <div className={getQualityColor(capture.geometryScore)}>
                        Geometry: {Math.round(capture.geometryScore * 100)}%
                      </div>
                      <div className="text-gray-400">Quality: {capture.quality}</div>
                      {capture.qualityMetrics && (
                        <div className="text-gray-400">
                          Symmetry: {Math.round(capture.qualityMetrics.symmetry * 100)}%
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        <canvas ref={canvasRef} className="hidden" />
      </div>
    </div>
  )
}

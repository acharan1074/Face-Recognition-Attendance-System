"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ArrowLeft, Download, Calendar, FileText, BarChart3, ImageIcon, Eye } from "lucide-react"
import Link from "next/link"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { generateDailyReport, exportToExcel as saveAsExcel } from "@/utils/excelExport"

interface AttendanceRecord {
  name: string
  rollNumber: string
  date: string
  time: string
  firstCaptureTime?: string
  captureCount?: number
  captureImages?: string[]
}

interface Student {
  id: string
  name: string
  rollNumber: string
  imageUrl: string
}

interface DailyStats {
  date: string
  present: number
  total: number
  percentage: number
}

export default function ReportsPage() {
  const [attendance, setAttendance] = useState<AttendanceRecord[]>([])
  const [students, setStudents] = useState<Student[]>([])
  const [filteredAttendance, setFilteredAttendance] = useState<AttendanceRecord[]>([])
  const [selectedStudent, setSelectedStudent] = useState<string>("all")
  const [dateFrom, setDateFrom] = useState("")
  const [dateTo, setDateTo] = useState("")
  const [dailyStats, setDailyStats] = useState<DailyStats[]>([])
  const [alert, setAlert] = useState<{ type: "success" | "error"; message: string } | null>(null)
  const [selectedRecord, setSelectedRecord] = useState<AttendanceRecord | null>(null)

  useEffect(() => {
    const savedAttendance = localStorage.getItem("attendance")
    const savedStudents = localStorage.getItem("students")

    if (savedAttendance) {
      const attendanceData = JSON.parse(savedAttendance)
      setAttendance(attendanceData)
      setFilteredAttendance(attendanceData)
    }

    if (savedStudents) {
      setStudents(JSON.parse(savedStudents))
    }

    // Set default date range (last 30 days)
    const today = new Date()
    const thirtyDaysAgo = new Date(today.getTime() - 30 * 24 * 60 * 60 * 1000)
    setDateFrom(thirtyDaysAgo.toISOString().split("T")[0])
    setDateTo(today.toISOString().split("T")[0])
  }, [])

  useEffect(() => {
    if (alert) {
      const timer = setTimeout(() => setAlert(null), 3000)
      return () => clearTimeout(timer)
    }
  }, [alert])

  useEffect(() => {
    applyFilters()
    calculateDailyStats()
  }, [attendance, selectedStudent, dateFrom, dateTo, students])

  const applyFilters = () => {
    let filtered = [...attendance]

    // Filter by student
    if (selectedStudent !== "all") {
      filtered = filtered.filter((record) => record.name === selectedStudent)
    }

    // Filter by date range
    if (dateFrom) {
      filtered = filtered.filter((record) => record.date >= dateFrom)
    }
    if (dateTo) {
      filtered = filtered.filter((record) => record.date <= dateTo)
    }

    setFilteredAttendance(filtered)
  }

  const calculateDailyStats = () => {
    if (!dateFrom || !dateTo || students.length === 0) return

    const stats: DailyStats[] = []
    const startDate = new Date(dateFrom)
    const endDate = new Date(dateTo)

    for (let date = new Date(startDate); date <= endDate; date.setDate(date.getDate() + 1)) {
      const dateStr = date.toISOString().split("T")[0]
      const dayAttendance = attendance.filter((record) => record.date === dateStr)
      const uniqueStudents = new Set(dayAttendance.map((record) => record.name))

      stats.push({
        date: dateStr,
        present: uniqueStudents.size,
        total: students.length,
        percentage: students.length > 0 ? Math.round((uniqueStudents.size / students.length) * 100) : 0,
      })
    }

    setDailyStats(stats)
  }

  const handleExportExcel = () => {
    if (filteredAttendance.length === 0) {
      setAlert({ type: "error", message: "No data to export" })
      return
    }

    const exportData = filteredAttendance.map((record) => ({
      "Roll Number": record.rollNumber,
      "Student Name": record.name,
      Date: new Date(record.date).toLocaleDateString(),
      Time: record.time,
      "Capture Count": record.captureCount || 1,
      Status: "Present",
    }))

    const filename = `attendance_report_${new Date().toISOString().split("T")[0]}.xlsx`
    saveAsExcel(exportData, filename, "Attendance Report")

    setAlert({ type: "success", message: "Excel report exported successfully!" })
  }

  const handleDailyReport = () => {
    if (students.length === 0) {
      setAlert({ type: "error", message: "No students found" })
      return
    }

    const today = new Date().toISOString().split("T")[0]
    const reportData = generateDailyReport(attendance, students, today)
    const filename = `daily_attendance_${today}.xlsx`

    saveAsExcel(reportData, filename, `Daily Report ${today}`)
    setAlert({ type: "success", message: "Daily Excel report exported successfully!" })
  }

  const getAttendanceRate = (studentName: string) => {
    const studentAttendance = attendance.filter((record) => record.name === studentName)
    const uniqueDates = new Set(studentAttendance.map((record) => record.date))
    const totalDays = dailyStats.length
    return totalDays > 0 ? Math.round((uniqueDates.size / totalDays) * 100) : 0
  }

  const getTotalCaptures = () => {
    return filteredAttendance.reduce((total, record) => total + (record.captureCount || 1), 0)
  }

  const viewCaptureImages = (record: AttendanceRecord) => {
    setSelectedRecord(record)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <Link href="/" className="inline-flex items-center text-blue-600 hover:text-blue-800 mb-4">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Dashboard
          </Link>
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Attendance Reports</h1>
          <p className="text-gray-600">Generate and analyze attendance data with capture information</p>
        </div>

        {alert && (
          <Alert
            className={`mb-6 ${alert.type === "success" ? "border-green-500 bg-green-50" : "border-red-500 bg-red-50"}`}
          >
            <AlertDescription className={alert.type === "success" ? "text-green-700" : "text-red-700"}>
              {alert.message}
            </AlertDescription>
          </Alert>
        )}

        {/* Filters */}
        <Card className="bg-white shadow-lg mb-6">
          <CardHeader>
            <CardTitle>Filters</CardTitle>
            <CardDescription>Filter attendance data by student and date range</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div>
                <Label htmlFor="student">Student</Label>
                <Select value={selectedStudent} onValueChange={setSelectedStudent}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select student" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Students</SelectItem>
                    {students.map((student) => (
                      <SelectItem key={student.id} value={student.name}>
                        {student.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="dateFrom">From Date</Label>
                <Input id="dateFrom" type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} />
              </div>

              <div>
                <Label htmlFor="dateTo">To Date</Label>
                <Input id="dateTo" type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} />
              </div>

              <div className="flex items-end gap-2">
                <Button onClick={handleExportExcel} className="flex-1">
                  <Download className="h-4 w-4 mr-2" />
                  Export Excel
                </Button>
                <Button onClick={handleDailyReport} variant="outline" className="flex-1 bg-transparent">
                  <FileText className="h-4 w-4 mr-2" />
                  Daily Report
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Statistics */}
          <div className="lg:col-span-1 space-y-6">
            <Card className="bg-white shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5" />
                  Statistics
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span>Total Records:</span>
                    <span className="font-bold">{filteredAttendance.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Total Captures:</span>
                    <span className="font-bold">{getTotalCaptures()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Unique Students:</span>
                    <span className="font-bold">{new Set(filteredAttendance.map((r) => r.name)).size}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Date Range:</span>
                    <span className="font-bold">{dailyStats.length} days</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Avg. Attendance:</span>
                    <span className="font-bold">
                      {dailyStats.length > 0
                        ? Math.round(dailyStats.reduce((sum, day) => sum + day.percentage, 0) / dailyStats.length)
                        : 0}
                      %
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Student Attendance Rates */}
            <Card className="bg-white shadow-lg">
              <CardHeader>
                <CardTitle>Student Attendance Rates</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 max-h-64 overflow-y-auto">
                  {students.map((student) => {
                    const rate = getAttendanceRate(student.name)
                    const studentRecords = filteredAttendance.filter((r) => r.name === student.name)
                    const totalCaptures = studentRecords.reduce((sum, r) => sum + (r.captureCount || 1), 0)

                    return (
                      <div key={student.id} className="flex justify-between items-center">
                        <div>
                          <span className="text-sm">{student.name}</span>
                          <div className="text-xs text-gray-500">{totalCaptures} captures</div>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="w-16 bg-gray-200 rounded-full h-2">
                            <div
                              className={`h-2 rounded-full ${rate >= 80 ? "bg-green-500" : rate >= 60 ? "bg-yellow-500" : "bg-red-500"}`}
                              style={{ width: `${rate}%` }}
                            />
                          </div>
                          <span className="text-sm font-medium w-10">{rate}%</span>
                        </div>
                      </div>
                    )
                  })}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Attendance Records */}
          <div className="lg:col-span-2">
            <Card className="bg-white shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="h-5 w-5" />
                  Attendance Records
                </CardTitle>
                <CardDescription>
                  {filteredAttendance.length} records found ({getTotalCaptures()} total captures)
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left p-2">Roll Number</th>
                        <th className="text-left p-2">Student Name</th>
                        <th className="text-left p-2">Date</th>
                        <th className="text-left p-2">Time</th>
                        <th className="text-left p-2">Captures</th>
                        <th className="text-left p-2">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="max-h-96 overflow-y-auto">
                      {filteredAttendance.map((record, index) => (
                        <tr key={index} className="border-b hover:bg-gray-50">
                          <td className="p-2 font-mono">{record.rollNumber}</td>
                          <td className="p-2 font-medium">{record.name}</td>
                          <td className="p-2">{new Date(record.date).toLocaleDateString()}</td>
                          <td className="p-2">{record.time}</td>
                          <td className="p-2">
                            <span className="inline-flex items-center gap-1">
                              <ImageIcon className="h-3 w-3" />
                              {record.captureCount || 1}
                            </span>
                          </td>
                          <td className="p-2">
                            {record.captureImages && record.captureImages.length > 0 && (
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => viewCaptureImages(record)}
                                className="text-xs px-2 py-1 h-6"
                              >
                                <Eye className="h-3 w-3 mr-1" />
                                View
                              </Button>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>

                  {filteredAttendance.length === 0 && (
                    <div className="text-center py-8 text-gray-500">
                      <Calendar className="h-12 w-12 mx-auto mb-4 opacity-50" />
                      <p>No attendance records found</p>
                      <p className="text-sm">Try adjusting your filters</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Capture Images Viewer Dialog */}
        {selectedRecord && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white p-6 rounded-lg shadow-xl max-w-4xl w-full mx-4 max-h-[80vh] overflow-y-auto">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-semibold">
                  Captures for {selectedRecord.name} on {new Date(selectedRecord.date).toLocaleDateString()}
                </h3>
                <Button onClick={() => setSelectedRecord(null)} variant="outline" size="sm">
                  Close
                </Button>
              </div>
              <div className="mb-4 text-sm text-gray-600">
                <p>Roll Number: {selectedRecord.rollNumber}</p>
                <p>First Capture: {selectedRecord.time}</p>
                <p>Total Captures: {selectedRecord.captureCount || 1}</p>
              </div>
              {selectedRecord.captureImages && selectedRecord.captureImages.length > 0 ? (
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {selectedRecord.captureImages.map((image, index) => (
                    <div key={index} className="border rounded-lg p-2">
                      <img
                        src={image || "/placeholder.svg"}
                        alt={`Capture ${index + 1}`}
                        className="w-full h-32 object-cover rounded"
                      />
                      <div className="text-xs text-gray-500 mt-1">Capture {index + 1}</div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-gray-500">
                  <ImageIcon className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>No capture images available</p>
                  <p className="text-sm">This record was marked manually</p>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

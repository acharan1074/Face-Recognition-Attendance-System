"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Users, Camera, FileText, Calendar, UserPlus, Eye, Database, Settings, Save } from "lucide-react"
import Link from "next/link"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { groupAttendanceByRollNumber } from "@/utils/rollNumberUtils"

interface AttendanceRecord {
  name: string
  rollNumber: string
  date: string
  time: string
}

interface Student {
  id: string
  name: string
  rollNumber: string
  imageUrl: string
}

export default function Dashboard() {
  const [students, setStudents] = useState<Student[]>([])
  const [todayAttendance, setTodayAttendance] = useState<AttendanceRecord[]>([])
  const [totalAttendance, setTotalAttendance] = useState(0)
  const [attendanceGroups, setAttendanceGroups] = useState<any[]>([])
  const [collegeName, setCollegeName] = useState("")
  const [tempCollegeName, setTempCollegeName] = useState("")
  const [isSettingsOpen, setIsSettingsOpen] = useState(false)
  const [alert, setAlert] = useState<{ type: "success" | "error"; message: string } | null>(null)

  useEffect(() => {
    // Load data from localStorage
    const savedStudents = localStorage.getItem("students")
    const savedAttendance = localStorage.getItem("attendance")
    const savedCollegeName = localStorage.getItem("collegeName")

    if (savedStudents) {
      const studentsData = JSON.parse(savedStudents)
      setStudents(studentsData)

      if (savedAttendance) {
        const attendance = JSON.parse(savedAttendance)
        const today = new Date().toDateString()
        const todayRecords = attendance.filter(
          (record: AttendanceRecord) => new Date(record.date).toDateString() === today,
        )
        setTodayAttendance(todayRecords)
        setTotalAttendance(attendance.length)

        // Group attendance by roll number patterns
        const groups = groupAttendanceByRollNumber(attendance, studentsData)
        setAttendanceGroups(groups)
      }
    }

    // Load custom college name
    if (savedCollegeName) {
      setCollegeName(savedCollegeName)
    }
  }, [])

  useEffect(() => {
    if (alert) {
      const timer = setTimeout(() => setAlert(null), 3000)
      return () => clearTimeout(timer)
    }
  }, [alert])

  const handleSaveCollegeName = () => {
    if (tempCollegeName.trim()) {
      setCollegeName(tempCollegeName.trim())
      localStorage.setItem("collegeName", tempCollegeName.trim())
      setAlert({ type: "success", message: "College name updated successfully!" })
      setIsSettingsOpen(false)
      setTempCollegeName("")
    } else {
      // Allow empty name to clear the college name
      setCollegeName("")
      localStorage.removeItem("collegeName")
      setAlert({ type: "success", message: "College name cleared successfully!" })
      setIsSettingsOpen(false)
      setTempCollegeName("")
    }
  }

  const handleOpenSettings = () => {
    setTempCollegeName(collegeName)
    setIsSettingsOpen(true)
  }

  const stats = [
    {
      title: "Total Students",
      value: students.length,
      icon: Users,
      description: "Registered students",
    },
    {
      title: "Today's Attendance",
      value: todayAttendance.length,
      icon: Calendar,
      description: "Students present today",
    },
    {
      title: "Total Records",
      value: totalAttendance,
      icon: FileText,
      description: "All attendance records",
    },
    {
      title: "Attendance Rate",
      value: students.length > 0 ? `${Math.round((todayAttendance.length / students.length) * 100)}%` : "0%",
      icon: Eye,
      description: "Today's attendance rate",
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8 flex justify-between items-start">
          <div>
            {/* College Name - displayed above the main system name */}
            {collegeName && <h2 className="text-2xl font-bold text-blue-800 mb-1">{collegeName}</h2>}
            {/* Main System Name - always displayed */}
            <h1 className="text-4xl font-bold text-gray-900 mb-2">Face Recognition Attendance System</h1>
            <p className="text-gray-600">Automated attendance tracking using advanced face recognition technology</p>
          </div>

          {/* Settings Button */}
          <Dialog open={isSettingsOpen} onOpenChange={setIsSettingsOpen}>
            <DialogTrigger asChild>
              <Button
                variant="outline"
                size="sm"
                onClick={handleOpenSettings}
                className="flex items-center gap-2 bg-white hover:bg-gray-50"
              >
                <Settings className="h-4 w-4" />
                Settings
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>System Settings</DialogTitle>
                <DialogDescription>
                  Add your college or organization name to display above the system title
                </DialogDescription>
              </DialogHeader>

              <div className="space-y-4">
                <div>
                  <Label htmlFor="collegeName">College/Organization Name</Label>
                  <Input
                    id="collegeName"
                    value={tempCollegeName}
                    onChange={(e) => setTempCollegeName(e.target.value)}
                    placeholder="Enter college name (e.g., ABC Engineering College)"
                    className="mt-1"
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    This name will appear above "Face Recognition Attendance System" on the main page
                  </p>
                </div>

                <div className="p-3 bg-gray-50 rounded-lg">
                  <p className="text-sm font-medium text-gray-700 mb-1">Preview:</p>
                  <div className="text-sm">
                    {tempCollegeName && <div className="text-blue-800 font-semibold">{tempCollegeName}</div>}
                    <div className="text-gray-900 font-bold">Face Recognition Attendance System</div>
                  </div>
                </div>

                <div className="flex gap-3">
                  <Button onClick={handleSaveCollegeName} className="flex-1">
                    <Save className="h-4 w-4 mr-2" />
                    Save Changes
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => {
                      setIsSettingsOpen(false)
                      setTempCollegeName("")
                    }}
                    className="flex-1"
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {alert && (
          <Alert
            className={`mb-6 ${alert.type === "success" ? "border-green-500 bg-green-50" : "border-red-500 bg-red-50"}`}
          >
            <AlertDescription className={alert.type === "success" ? "text-green-700" : "text-red-700"}>
              {alert.message}
            </AlertDescription>
          </Alert>
        )}

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <Card key={index} className="bg-white shadow-lg hover:shadow-xl transition-shadow">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">{stat.title}</CardTitle>
                <stat.icon className="h-4 w-4 text-blue-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-gray-900">{stat.value}</div>
                <p className="text-xs text-gray-500 mt-1">{stat.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Action Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="bg-white shadow-lg hover:shadow-xl transition-all hover:scale-105">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <UserPlus className="h-5 w-5 text-green-600" />
                Manage Students
              </CardTitle>
              <CardDescription>Add, remove, or update student information and photos</CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/students">
                <Button className="w-full bg-green-600 hover:bg-green-700">Manage Students</Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="bg-white shadow-lg hover:shadow-xl transition-all hover:scale-105">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Camera className="h-5 w-5 text-blue-600" />
                Take Attendance
              </CardTitle>
              <CardDescription>Start live face recognition to mark attendance</CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/attendance">
                <Button className="w-full bg-blue-600 hover:bg-blue-700">Start Recognition</Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="bg-white shadow-lg hover:shadow-xl transition-all hover:scale-105">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5 text-purple-600" />
                View Reports
              </CardTitle>
              <CardDescription>Generate and download attendance reports</CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/reports">
                <Button className="w-full bg-purple-600 hover:bg-purple-700">View Reports</Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="bg-white shadow-lg hover:shadow-xl transition-all hover:scale-105">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="h-5 w-5 text-orange-600" />
                Data Management
              </CardTitle>
              <CardDescription>Manage data, cleanup old records, and organize by groups</CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/data-management">
                <Button className="w-full bg-orange-600 hover:bg-orange-700">Manage Data</Button>
              </Link>
            </CardContent>
          </Card>
        </div>

        {/* Attendance Groups Overview */}
        {attendanceGroups.length > 0 && (
          <Card className="bg-white shadow-lg mb-8">
            <CardHeader>
              <CardTitle>Attendance Groups Overview</CardTitle>
              <CardDescription>Today's attendance organized by year and department</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {attendanceGroups.slice(0, 6).map((group, index) => (
                  <div key={index} className="p-4 border rounded-lg bg-gray-50">
                    <h4 className="font-medium text-sm mb-2">{group.groupName}</h4>
                    <div className="flex justify-between text-sm">
                      <span>
                        Present: {group.presentToday}/{group.totalStudents}
                      </span>
                      <span className="font-medium">{group.attendanceRate}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
                      <div className="bg-blue-600 h-2 rounded-full" style={{ width: `${group.attendanceRate}%` }}></div>
                    </div>
                  </div>
                ))}
              </div>
              {attendanceGroups.length > 6 && (
                <div className="text-center mt-4">
                  <Link href="/data-management">
                    <Button variant="outline" size="sm">
                      View All Groups ({attendanceGroups.length - 6} more)
                    </Button>
                  </Link>
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* Recent Attendance */}
        {todayAttendance.length > 0 && (
          <Card className="bg-white shadow-lg">
            <CardHeader>
              <CardTitle>Today's Attendance</CardTitle>
              <CardDescription>Students who have been marked present today</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {todayAttendance.slice(0, 5).map((record, index) => (
                  <div key={index} className="flex justify-between items-center p-2 bg-gray-50 rounded">
                    <div>
                      <span className="font-medium">{record.name}</span>
                      <span className="text-sm text-gray-500 ml-2">({record.rollNumber})</span>
                    </div>
                    <span className="text-sm text-gray-500">{record.time}</span>
                  </div>
                ))}
                {todayAttendance.length > 5 && (
                  <div className="text-center pt-2">
                    <Link href="/reports">
                      <Button variant="outline" size="sm">
                        View All ({todayAttendance.length - 5} more)
                      </Button>
                    </Link>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}

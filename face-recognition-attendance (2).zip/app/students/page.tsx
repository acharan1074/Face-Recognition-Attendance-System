"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { UserPlus, Trash2, Camera, Upload, ArrowLeft } from "lucide-react"
import Link from "next/link"
import { Alert, AlertDescription } from "@/components/ui/alert"

interface Student {
  id: string
  name: string
  rollNumber: string
  imageUrl: string
  dateAdded: string
}

export default function StudentsPage() {
  const [students, setStudents] = useState<Student[]>([])
  const [newStudentName, setNewStudentName] = useState("")
  const [newStudentRollNumber, setNewStudentRollNumber] = useState("")
  const [selectedImage, setSelectedImage] = useState<string | null>(null)
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [isCapturing, setIsCapturing] = useState(false)
  const [alert, setAlert] = useState<{ type: "success" | "error"; message: string } | null>(null)

  const fileInputRef = useRef<HTMLInputElement>(null)
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const savedStudents = localStorage.getItem("students")
    if (savedStudents) {
      setStudents(JSON.parse(savedStudents))
    }
  }, [])

  useEffect(() => {
    if (alert) {
      const timer = setTimeout(() => setAlert(null), 3000)
      return () => clearTimeout(timer)
    }
  }, [alert])

  const saveStudents = (updatedStudents: Student[]) => {
    setStudents(updatedStudents)
    localStorage.setItem("students", JSON.stringify(updatedStudents))
  }

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (e) => {
        setSelectedImage(e.target?.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const startCamera = async () => {
    try {
      setIsCapturing(true)
      const stream = await navigator.mediaDevices.getUserMedia({ video: true })
      if (videoRef.current) {
        videoRef.current.srcObject = stream
      }
    } catch (error) {
      setAlert({ type: "error", message: "Failed to access camera" })
      setIsCapturing(false)
    }
  }

  const capturePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const canvas = canvasRef.current
      const video = videoRef.current
      canvas.width = video.videoWidth
      canvas.height = video.videoHeight

      const ctx = canvas.getContext("2d")
      if (ctx) {
        ctx.drawImage(video, 0, 0)
        const imageData = canvas.toDataURL("image/jpeg")
        setSelectedImage(imageData)

        // Stop camera
        const stream = video.srcObject as MediaStream
        stream?.getTracks().forEach((track) => track.stop())
        setIsCapturing(false)
      }
    }
  }

  const addStudent = () => {
    if (!newStudentName.trim() || !newStudentRollNumber.trim() || !selectedImage) {
      setAlert({ type: "error", message: "Please provide name, roll number, and image" })
      return
    }

    // Check for duplicate roll number
    const existingStudent = students.find((s) => s.rollNumber === newStudentRollNumber.trim())
    if (existingStudent) {
      setAlert({ type: "error", message: "Roll number already exists" })
      return
    }

    const newStudent: Student = {
      id: Date.now().toString(),
      name: newStudentName.trim(),
      rollNumber: newStudentRollNumber.trim(),
      imageUrl: selectedImage,
      dateAdded: new Date().toISOString(),
    }

    const updatedStudents = [...students, newStudent]
    saveStudents(updatedStudents)

    setNewStudentName("")
    setNewStudentRollNumber("")
    setSelectedImage(null)
    setIsDialogOpen(false)
    setAlert({ type: "success", message: "Student added successfully!" })
  }

  const removeStudent = (id: string) => {
    const updatedStudents = students.filter((student) => student.id !== id)
    saveStudents(updatedStudents)
    setAlert({ type: "success", message: "Student removed successfully!" })
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8 flex items-center justify-between">
          <div>
            <Link href="/" className="inline-flex items-center text-blue-600 hover:text-blue-800 mb-4">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Dashboard
            </Link>
            <h1 className="text-4xl font-bold text-gray-900 mb-2">Student Management</h1>
            <p className="text-gray-600">Add, remove, and manage student profiles</p>
          </div>

          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-green-600 hover:bg-green-700">
                <UserPlus className="h-4 w-4 mr-2" />
                Add Student
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Add New Student</DialogTitle>
                <DialogDescription>Enter student details and capture or upload their photo</DialogDescription>
              </DialogHeader>

              <div className="space-y-4">
                <div>
                  <Label htmlFor="name">Student Name</Label>
                  <Input
                    id="name"
                    value={newStudentName}
                    onChange={(e) => setNewStudentName(e.target.value)}
                    placeholder="Enter student name"
                  />
                </div>

                <div>
                  <Label htmlFor="rollNumber">Roll Number</Label>
                  <Input
                    id="rollNumber"
                    value={newStudentRollNumber}
                    onChange={(e) => setNewStudentRollNumber(e.target.value)}
                    placeholder="Enter roll number"
                  />
                </div>

                <div>
                  <Label>Student Photo</Label>
                  <div className="space-y-2">
                    {!isCapturing ? (
                      <div className="flex gap-2">
                        <Button variant="outline" onClick={() => fileInputRef.current?.click()} className="flex-1">
                          <Upload className="h-4 w-4 mr-2" />
                          Upload Photo
                        </Button>
                        <Button variant="outline" onClick={startCamera} className="flex-1 bg-transparent">
                          <Camera className="h-4 w-4 mr-2" />
                          Take Photo
                        </Button>
                      </div>
                    ) : (
                      <div className="space-y-2">
                        <video ref={videoRef} autoPlay className="w-full rounded-lg" />
                        <Button onClick={capturePhoto} className="w-full">
                          Capture Photo
                        </Button>
                      </div>
                    )}

                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      onChange={handleImageUpload}
                      className="hidden"
                    />

                    {selectedImage && (
                      <div className="mt-2">
                        <img
                          src={selectedImage || "/placeholder.svg"}
                          alt="Selected"
                          className="w-full h-32 object-cover rounded-lg"
                        />
                      </div>
                    )}
                  </div>
                </div>

                <Button onClick={addStudent} className="w-full">
                  Add Student
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {alert && (
          <Alert
            className={`mb-6 ${alert.type === "success" ? "border-green-500 bg-green-50" : "border-red-500 bg-red-50"}`}
          >
            <AlertDescription className={alert.type === "success" ? "text-green-700" : "text-red-700"}>
              {alert.message}
            </AlertDescription>
          </Alert>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {students.map((student) => (
            <Card key={student.id} className="bg-white shadow-lg hover:shadow-xl transition-shadow">
              <CardHeader className="pb-2">
                <div className="aspect-square relative overflow-hidden rounded-lg bg-gray-100">
                  <img
                    src={student.imageUrl || "/placeholder.svg"}
                    alt={student.name}
                    className="w-full h-full object-cover"
                  />
                </div>
              </CardHeader>
              <CardContent>
                <CardTitle className="text-lg mb-1">{student.name}</CardTitle>
                <CardDescription className="text-sm mb-3">
                  Roll No: {student.rollNumber}
                  <br />
                  Added: {new Date(student.dateAdded).toLocaleDateString()}
                </CardDescription>
                <Button variant="destructive" size="sm" onClick={() => removeStudent(student.id)} className="w-full">
                  <Trash2 className="h-4 w-4 mr-2" />
                  Remove
                </Button>
              </CardContent>
            </Card>
          ))}

          {students.length === 0 && (
            <div className="col-span-full text-center py-12">
              <UserPlus className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No students added yet</h3>
              <p className="text-gray-500 mb-4">Start by adding your first student to the system</p>
              <Button onClick={() => setIsDialogOpen(true)} className="bg-green-600 hover:bg-green-700">
                <UserPlus className="h-4 w-4 mr-2" />
                Add First Student
              </Button>
            </div>
          )}
        </div>

        <canvas ref={canvasRef} className="hidden" />
      </div>
    </div>
  )
}
